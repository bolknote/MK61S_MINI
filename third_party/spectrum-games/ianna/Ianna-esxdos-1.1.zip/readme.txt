This ZIP contains the ESXDOS-compatible version of The Sword of Ianna. To run
it, just copy the contents of the "iannasd" folder to a SD card (or Compact
Flash), run it on your Spectrum with ESXDOS, and then:

- Use the NMI browser to load the "LOADER" file
- Or navigate to the folder using ".cd" commands and do:

LOAD *"LOADER"
