Original507 accepted separate-component union418=412strict+6equal;89 original remain(pow51/exp2/sin22/cos14). rsqrt independent receipt90181e2e verified22 direct refs; source packet unchanged.

New private d2f leaf .build/m0-d2f-leaf-20261024:231984 inputs fully profiled,1391904 fresh ARM/231984 MPFR,0wrong/0correct-Qfplib speed losses;426 old sampled conversion deficits->0. Source RNE and instruction-path proof awaits independent review.256-byte body(+188 selected ASM bytes),0stack/tables/RAM/libgcc/SIO, generic M0/M4 unchanged.110782 parent-cost increases of1 retained and all <=correct Qfplib. Postseal60artifacts/362lineage passes.

Still open:f2d sampled1, FMA independent/hardware acceptance, pow7904 expanded/general1024-bit totality, exp395/ln5 expanded, original89, combined repaired-platform integration/regression and physical cycles/device acceptance. No canonical/Git/device/release changes and no whole-goal GO.


F2D leaf frozen931cce0b…/result1dc77e5f… in .build/m0-f2d-leaf-20261024: 132959 unique inputs,797754 fresh ARM calls,0wrong/0correct-Qfplib losses, old sample1->0 and raw parent4->0. Whole-binary32 returned-value source proof and complete Qfp-correct ISA partition; normal13->12, zero28->5(Qfp8), infinity37->12(Qfp12).172-byte leaf(+138selectedASM), stack/SIO0, no new tables/RAM/libgcc/external calls. All other RP sections including accepted d2f and selected genericM0/M4 ASM equal; four byte-exact whole object/ELF rebuilds. Postseal61/424 verified. F2D independent review/integration/devicecycles OPEN. Additive oracle accounting is in .build/m0-f2d-leaf-postseal-20261024.json, no frozen edits. D2F independent receipt500e2c5b… GO_PRIVATE_RP_D2F_LEAF_COMPONENT_ONLY and27directrefs verified: own27496ARM/3437directMPFR. D2F author 231984 oracle evaluations =229580 actual directedMPFR conversions +2404 NaN shortcuts. Original507 separate union418/residual89 unchanged. No canonical/Git/device/Flash/lease/release changes.


New frozen author exp tiny-cell component .build/m0-exp-tiny-radius-20261024: sourced31f2f4d0b90c21618b5e58c49e6699a813f32cbef60b456155dc8de7145ffe9, ELFceb2b842be27fb9f92ccbdf0dc0fd7f2ebdb18bab9fbef1ef03104ba6e2607aa. Exact whole-domain2^-54<abs(x)<2^-38 rounding via odd-square midpoint geometry, no iterative tiny fallback.49153cells/442299modelchecks, bothcriticalneighbors publicARM+MPFR eachcell.163675inputs/327350states:558134freshqualifiedARM(327350candidate+229824Qfp+960parentaudit),163673actualdirectedMPFR+2sNaNshortcuts;old97526baseline measurements inherited/notnew,smoke10446excluded,0wrong. Sameold48763 corpus395->154(241fixed); larger163675corpus669=154old+514newdense2^-38boundary+1ordinarypreexistingloss. Every669loss parentbound,0new,wrongQfp115028states retained. Tinypublic74..96ISA,example17117->96vsQfp527. +64CPPbytes(core5144->5012,newhelper196),staticcore88->96stack/helper20; observedoverall376vsold736.13234knownparentcostincreasesretainedandallstillfasterQfp. AllotherCPPsections/relocs unchanged; wholeRPASMexactF2Dparentincludingconversions;genericM0/M4CPPexact,inheritedASMcontrols;6wholeobjectELFrebuildsbyteexact. AcceptedF2Dreview7561feddf77fd13a7760b930414e68f997898526abaed866c909d39a7efcaeb2and28receipt/directrefsverified. Newexpindependentreviewpending,original507union418/residual89 unchanged; pow7904/ln5/sin22/cos14/FMA/generalpowtotality/combinedintegration/devicecycles remainopen. Postseal80/513pinsverified;nocanonical/Git/device/Flash/lease/release changes.


Frozen author log-midpoint exp .build/m0-exp-tiny-log-midpoint-20261024: FROZEN5dfdd55a763a5b0b8eafee876d1b348ec917632a10e1d31b3975dc4fe72f9f1f, result42cdd6d6be73fd2fe2527fba9bc56a1a6e8cf5013848fc1671a92cae4f9536d1, CPP1cc8f86cf948efbc152b7bf7f1f15046b0be2d0d5f9e07552305b514fc92a899,ELF43bcd8e12044ddd81d8d0d2aa12701e966c4ad3c76f755eb926406cc36bcbf54. Exact tiny domain2^-54<abs(x)<2^-32 expands64fold.3145728oddclasses log-tail integercertificate+65536reciprocal3cases,154cubicthreshold corrections allactualARM/MPFRbound616states.428231inputs/856462states:1386602freshqualifiedARM(856462candidate529112Qfp1028parentaudit),428229actualdirectedMPFR+2sNaN.327350oldbaseline states inherited/notnew;smoke24898/trial24854/diagnostic2excluded.0wrong,allold163675rawbitsidentical. Sameold163675losses669->155,514fixed; sameolder48763still154. New428231union671=155old+514new2^-32edges+2ordinarypreexistinglosses,all671parentcostbound,0new,allwrongQfp385334statesretained. Tinyobserved83..200instructions,edge520->88vs466/542->84vs528. +276CPP/privateFlashload+280alignment,helper196->472/core5012samewithonly38->32ADDSbytechanged. Staticcore96same/helper20->56,observedmax376same.239986knownparentcostincreasesretainedandallstillfasterQfp. AllotherCPPsections/relocsandfullRPASM/d2ff2dexact;genericM0/M4CPPexact,ASMsourceunchanged;6wholeobjectELFrebuildsexact. Acceptedparentac32571a…receipt+38directrefsread/verifiedbeforeseal,privatecomponentonly. Original507union418/residual89unchanged,originalexp2remain2268/2248vs649/622,actualrefineentry546/558profileguidesnextcheapmiddlepass. Postseal88artifacts621lineagepinsverified. Newreview/expandedexp671/pow7904/ln5/sin22/cos14/FMA/generalpowtotality/combinedintegration/devicecyclesOPEN,nocanonical/Git/USB/Flash/device/lease/EA9/releasechanges.


Adaptive exp/shared-product author delta frozen de974c59 in .build/m0-exp-adaptive-enclosure-20261024. Parent log-midpoint independent review bdaba8cf GO,48 direct refs verified. New exp:440007 inputs,0wrong/0new speed losses; same428231 losses671->642,29fixed; expanded2023=642old+1381new confirmed preexisting. Original negative exp2248->599vsQfp622; positive2268->2264vs649 remains. Original separate union419(413strict6equal),88remain; independently reviewed418 unchanged. Product84->81 universally,168->162activeB plus6outside NOPs preserve168B slot;40B frame unchanged. Other callers allbits/argumenttraces identical,minus3instructions per product call. Pow7904 old losses unchanged after10081fresh candidate state replays; no full111912-pair reacquisition/newMPFR. Total1653867 fresh qualified ARM,440194 actual directedMPFR validation inputs+2sNaN; excluded diagnostic/rejected/failed runs not pooled. CPP+52/privateFlash+48, no tables/RAM/libgcc. M0/M4 selected CPP+ASM equal,11 rebuilds byte-exact. Postseal143local/741external pins verified. New independent review, combined integration, physical cycles, general totality and remaining speed gaps open. No canonical/Git/USB/device/Flash/lease/EA9/release changes. Goal active.


Exact dyadic exp/shared79 product frozen acdaac6247165b8b53d3e48dadff2629577e1abd073d2604105cf2f05254031b in .build/m0-exp-dyadic-product-20261024; source parent adaptive de974c59 and child both independent review pending. Same440007 exp2023->1476(547fixed); full456750 corpus1541=1476old+65new confirmed preexisting losses,0wrong/0new. Examples +2^-32 520->439vs471; -2^-32 542->461vs520. Shared product81->79,frame40->36,168B slot unchanged,code+24/no tables. Pow7904->7901 with3original cases becoming ties; original separate authorunion422(413strict9equal),85remain(pow48exp1sin22cos14). Full456750 exp inputs913500states;1169745qualified freshARM/456937actual directedMPFR+2sNaN.11byteexactrebuilds,all other RP bytes/relocs and selected M0/M4 equal. Postseal130artifacts/887externalpinsverified. Author results only; reviewed418unchanged. Expanded1541exp/7901pow/5ln,FMA,general totality,combinedintegration/hardwarecycles/releaseopen. No canonical/Git/USB/device/Flash/lease/EA9/release changes;goalactive.


Directed exp/shared77 author delta frozen e6ce7678 in .build/m0-exp-directed-product-20261024, independent review pending. All295local/1050external pins verified; postseal receipt outside packet. Same456750exp losses1541->1530,11fixed; expanded467366 union1896 includes366new measured preexisting losses. Lastoriginalexp2266->612vs649; alloriginalexp16strict. Sharedproduct79->77 fixed, same36Bframe/168Bslot. Pow7901losses unchanged; threeprior ties nowstrict1342/1318/1309vs1344/1320/1311.1386951qualifiedARM,467553actualdirectedMPFR+2sNaN. CPP/privateFlash+120B,no tables; M0/M4 selectedequal. PrivateR12fraction contract requires mandatory actual linked call-to-marker guard on every changed release object; component builder runs it. Authororiginal507union423=417strict6equal/84remaining; reviewed422unchanged. No integration/canonical/Git/USB/device/Flash/lease/EA9/release mutation. General totality/FMA/expandedlosses/combinedregressions/physicalcycles remain open; goal active.


Near-one exp author candidate frozen1e5a757a in .build/m0-exp-near-one-20261024. Accepted directed parent private review0d6073f3/ROOT7ec53f3c verified; global reviewed422explicitly retained. Same4673661896->196,1700fixed; expanded490031214=196old+18new measured preexisting,allremainingparent-bound,0wrong/0new.1203570qualifiedARM/490029actualdirectedMPFR+2sNaN;2688loggenerations separate. Code/privateFlash+1136,no tables/RAM/libgcc/ROMmath; publicframe96->88/helper72,observedpeak744->808. Shared77product unchanged; genericM0/M4selectedCPP/allotherCPPallocrelocsequal;11byteexactrebuilds. MandatoryR12guard strengthened to fresh actualdisassembly,2postcall/88consumer-live instructions,17negativeASTcontrols. Frozen167local/1389external pins verified,postsealoutsidepacket. Independentreview/integration/FMA/general totality/remainingexp214,pow7901,ln5,sin/cos deficits/physicalcycles/release open. No canonical/Git/USB/device/Flash/lease/EA9/release mutation. Goal active.


## Near-one component acceptance, 2026-10-25

The later independent receipt `m0-exp-near-one-independent-20261025/FINAL-REVIEW.json`
(6c504f888e1ce0489379d1769b2d1e331b64bda0354eed746fbe98359748634b) and ROOT
receipt `m0-exp-near-one-root-acceptance-20261025-001/RECEIPT.json`
(0831d62fc51c2be190afc220525bb52974d83c5b236bba07359f6946d02c74a5)
accept only the private near-one exp component. All 51 direct ROOT pins
were reverified here. The exact middle-product error interval is (-3, 0],
as clarified by 03ceff8e6e0f9e8ca790567f2045f1791c301f1544d2c0f8aaa234a19496c179.
Earlier pending-review wording and author counts remain historical.
The reviewed original507 union stays422 (413 strict, nine equal); no
automatic promotion to author423, integration, hardware or release GO.
Fresh integration must rerun the actual linked R12 guard. All214 expanded
exp losses, 428 losing states, 5712 parent cost increases and observed
808-byte stack remain explicit. Independent reviewer calls are separate
from author qualification totals.


## Table-only pow product, 2026-10-25

Frozen private packet: `.build/m0-pow-exp-table-product-20261025`.
Originalpow48->35 (13 strict fixes,118strict/153); old111912pairs7901->7888.
Widened116468pairunion10866->10853,0wrong/0new; additional2965 measured
loss pairs preexist in parent. All8024 +2instruction states and60686
wrong-Qfplib state variants retained.314546qualifiedfreshARM,4785actual
directedMPFR+76sNaN shortcuts. Code+32B; no newtables/globalRAM/libgcc;
scratch4080B unchanged; same-corpus observedparent/control/candidate
stack2284B.20completeobject/ELFrebuilds byteexact, M4/defaultM0 controls
equal. General77 product/R12extra unchanged; newprivate table entry10
dyadic/79generic. Independent review pending. Author507436=430strict
+6equal,71remain(pow35/sin22/cos14); reviewed507kept422 perROOT.
Source merge/relink and fresh actual integrated R12guard remain necessary.
This is not integration, hardware, physicalcycle, totality or release GO.
The full R union includes its qualified focused `probe.json`; the new
packet preserves that report in lineage to close the earlier portable
checkpoint's generic-probe omission. No old frozen file is rewritten.


## Exact square128 author qualification, 2026-10-25

Authoritative packet `.build/m0-pow-square128-r2-20261025`, FROZEN
31de9242e96642ed7de050a2a7a51a5baeacdd9c8842e4b0d7f3f2c74e2e681d.
All69 local+1585external pins verified. First seal is explicitly rejected only
for a late producer-log pin; original data and invalid historical seal retained.
No numerical or binary changes in the reissue, no rerun/double counting.
Kernel saves27-41instructions, frame incl helper68->60B, same310B slot.
Same116468-pair pow losses10853->10850; new120980-pair union11449->11434,
596 new measured preexisting losses,15fix0new0wrong0parentcostincreases.
330880qualifiedARM,5051directedMPFR+76sNaN shortcuts; pilot918 excluded.
Originalpow35->34, author507437=431strict+6equal;70remain(pow34/sin22/cos14).
Reviewed507 remains422. Square independent review, totality, remaining math,
merged actual R12/loader/layout guards, cycles and release remain pending.
Parent table component now has ROOT09b8c732 acceptance. Next study: wider
provably bounded integer-power decoder/chains; no precision relaxation.


## Exact boundary128 reuse, 2026-10-25

Packet `.build/m0-pow-boundary128-20261025`, FROZEN `61c98b938cf723f2f9b63ef06f22a3033c1b07af979dbe56ef9a2a2d56ed3393`.
All68local+1695externalpins passed. Parent square now has
independentTECH_GOeaa55a85; this new caller still awaits separate review.
Complete120980pairs/241960states:454states save4-169instructions,0increases,
0wrong/0newloss. Rawloss11434 andoriginal34 unchanged;author507437 and
reviewed507422 unchanged. All24midpoint bytes/sides identical; bareframe
212->156; +228Bdiagnostic code,17byteexactrebuilds, M4/defaultM0 unchanged.
309938qualifiedARM,5051directedMPFR+76sNaN. Rejected80bit trial21,057ARM/153MPFR
excluded; exact required gaps97-108bits. Fullprecision128 retained.
Next measure actual1/hint reciprocal division before a certified specialized
path; main/merged guards/totality/othermath/cycles/release still pending.


Boundary128 report corrigendum: full public saving range is4-180, not the4-169 original153 pilot range. Two rows save180. .build/m0-pow-boundary128-report-corrigendum-20261025.json SHA729a5e184850786b02c03c2dc40d97d4eed43e1bc0c65753f0af9f2fe6385997. All raw evidence/frozen files unchanged;0newARM/MPFR.


## DIRTY reciprocal continuation, 2026-10-25

Author packet `.build/m0-pow-reciprocal-soft-20261025` is sealed as
FROZEN13dc7f8186d4678fac6b7a0da0b27e00dbb678316e292d320d3eefdd35dbba0c.
Same120980-pair corpus:11434->11386 loss pairs,48 strict fixes,0new/0wrong;
377 DIRTY states save311-380 instructions and READY counts stay unchanged.
842693 fresh ARM calls,6761 directed MPFR plus184 sNaN shortcuts,65536 exact
integer/dyadic oracle inputs; pilot1836/153MPFR and inherited66288 seed
calls excluded. All936 direct wrong-Qfplib rows and77106 public variants
retained.26 exact source/object/ELF rebuilds;81local+1814external pins pass.
The282B common RNE tail and194B seed match their checked parents. SIO7
words preserved; private seed call SP aligned8. Diagnostic code1050B
includes duplicate existing32B dyadic constants, no new table values/RAM/
libgcc. Other ddiv callers remain original; M4/defaultM0 controls unchanged.
Full observed stack2284 and fresh controls2148 unchanged; changed-parent388
subset is not a full comparison. Original153 remains119strict/34slower;
author separate507 stays437, reviewed422. Parent boundary ROOT260cb67e now
accepted, while this new component review and actual source integration,
R12/loader/layout guards, all-needed-math speed/totality/cycles/release remain
open. No device/USB/Flash or Git changes in this goal turn. Goal stays active.


## Exact small-table seed caller, 2026-10-25

Frozen `.build/m0-pow-reciprocal-lut-20261025`:
7384323f37dae2fb8a7cf350a64165392181e20276e83551ccf9ef320d811ffc.
All67local+1978external pins pass. Seed56B+table256B=312B vsold194B;
private section1050->1168B (+118B),20-27 instructions vs82-97.
Complete divisor domain and all16 NZCV table edges,155680 selectedbare
calls pass;233520 other-variant calls excluded. Final selection is based
on full-domain worst latency, not the same-nine-fixes current sample.
Same120980-pair corpus11386->11377 losses,9 strict fixes,377 DIRTY states
save59-73 instructions,0wrong/new/parentcostincreases. READY unchanged.
476133 qualified fresh ARM,6761 MPFR+184sNaN; failed24ARM/3MPFR calibration
excluded.18 exact rebuilds; all actual caller deltas equal measured seed
savings. RNE/setup/otherresidentbytes, SIO7words, R1/R12/PCS preserved.
New R3clobber is saved/restored by private caller. M4/defaultM0 controls
unchanged. Parent reciprocal independent TECH_GO211cf956 received; parent
ROOT receipt absent at child seal. This child needs its own review.
Full stack2284 and controls2148 unchanged. Original15334 and author507437/
reviewed422 unchanged. No global ddiv/canonical/Git/device/Flash change.
Next study exact first product for numerator1; overall math goal is active.


## Private numerator-one reciprocal, 2026-10-25

Frozen `.build/m0-pow-reciprocal-one-20261025`:
3341f37fa8b5a5177af792be2417b1365c5b6595f66280151e5ed6f72d8c5469.
80local+2142external pins pass. Sole root BL source/dynamic contract is
exact positive1; other ddiv callers unchanged. Equivalent exponent guards,
exact first product, dead SW unpack:5 strict fixes, loss11377->11372 on same
120980pairs;778 states save11-34 instructions (389 READY,389 DIRTY), no
wrong/new/parentincreases. Privatecode1168->1060B (-108), seed312B unchanged,
no new tables/RAM/libgcc.186B after-second-product RNE suffix identical.
406406freshARM,17785MPFR+110sNaN,22 exact rebuilds; supersededv1 and failed
trace calls excluded. Original15334 /author507437 /reviewed422 unchanged.
Parent LUT now has independent TECH_GO; this new caller review pending.
The frozen HANDOFF accidentally reported all18 normal scalar losses as2-5
instructions; this was READY only. External corrigendum records correct
READY2-5 /DIRTY15-21 /overall2-21, raw records and frozen bytes unchanged.
See `.build/m0-pow-reciprocal-one-report-corrigendum-20261025.json`.
All216 scalar loss states/18 denominators stay explicit, including198
subnormal overflow candidates. Next derive fast exact overflow handling
and inspect rare remainder/seed/sign overhead without changing RNE/domain.
No canonical/M4/Git/device/Flash/integration/hardware/release change.


## Inline seed and exact tiny overflow, 2026-10-25

Frozen `.build/m0-pow-reciprocal-inline-20261025`:
0be351d573878a48f13f5d41edd2812a23ab269556b929db9aa8324e6a0bf219.
94local+2281external pins pass. Correct private1/x RNE infinity threshold
is subnormal integer magnitude<=2^50; exact endpoint products prove it.
Inline seed preserves R0/R1/R2/R3/R5/R12/SP over all65536 divisors and all16
flags on table edges,143392 fresh bare-context calls. Source/table unchanged
arithmetically; standalone312B helper no longer allocated, table256B moved.
Expanded scalar20994pairs/41988states:7422->13 Qfplib losses, no new Qfp
loss;32370 faster/5equal/13slower. All9600 wrong references and9664 parent
cold increases (+2,+8,+11) retained. Same120980-pair pow11372->11371 losses,
one strict fix,754 faster states save2-7 instructions;778 parent replays
include24 unchanged power-of-two controls. Earlier commentary equality
referred to another reference-state variant; the closed pair is strict.
615606 fresh ARM,26011 MPFR+110sNaN,24 exact rebuilds. New code1072B (+12),
no new table values/RAM/libgcc, M4 unchanged. Fullstack2284/controls2148/
scalar176 unchanged. Original15334 and author507437/reviewed422 unchanged.
Parent one independent TECH_GO present; new child review pending. Failed
symbol0 and stack318 completed+2partial/23MPFR preflights excluded.
Next study exact partial-product remainder certificate, then unified actual
source/relink with integratedR12/loader/layout checks. No canonical/Git/
device/USB/Flash, hardware/main/release GO. Overall goal stays active.


Exact remainder certificate frozen99110367 in .build/m0-pow-reciprocal-certificate-20261025, ELF aac32d20.673814 fresh qualifiedARM,26011directedMPFR+110sNaN,22byteexactsource rebuilds. Same120980pairs11371->11369(1strict1tie), original15334->33.354publicstates save12..15;32add7..8 with0newQfp losses. Additive corrigendum5cd5994f corrects HANDOFF:2of32 were already slower and get slower still; the other30 have no correct Qfp reference. Scalar13->1(149vs146 DIRTY D3FF27D0DF6735E90),1132parent increases retained and noneQfpslow. Shared unit100800tests201600ARM, every real certificate branch and complete live state checked; exact integer bound131071 and old full fallback preserve RNE. Code1072->1108(+36),same256Btable, M4/defaultunchanged/noRAM/libgcc. Bareunit904e63f0.80local2402externalpostsealPASS. Author separate507438=432strict6equal, reviewed422unchanged. Parentinline and newcertificate independent reviews pending. Next preserve knownzero through second product/certificate for remaining3instructions, then unifiedprivate source merge/relink/R12/loader/layout/14Bhazard. Othermath/generalpowtotality/physicalcycles/release open. No canonical/Git/USB/device/Flash changes; goal active.


Known-zero reciprocal frozen98efecf0 in .build/m0-pow-reciprocal-zero-20261025, ELFa2957007; unitr3eec45d9e.1460246 freshqualifiedARM/157083directedMPFRinputevaluations+110sNaN(overlapsnotunique),22byteexactrebuilds. Same scalar1->0(32387fast1tie), expanded all65536D/two normalmantissas131072inputs/262144states:14->2losses(262131fast11tie2slow), allrefs correct. RemainingDIRTY D3FF0CEE65125761B149vs146 andD3FF10E0E8502C07D147vs146, both seed estimates qerror3. Current parent0costincreases/0newQfploss; previouscertificate cumulativeincreases remain retained. Public11369unchanged,754states-2..3; original15333same/authorseparate507438same/reviewed422same. Knownzero source permutation gives full after-residual join, certificateR3preservesR6zero, fallback explicitlyrestores; no inherited unchanged186Bsuffixclaim. Code1108->1100(-8),same256Btable/M4defaultcontrols/6emptydisabled. Stackwhole2284/freshpublic2148/samescalar176 unchanged; expandednormal28differentcorpusnotreduction.79local2567externalpostsealPASS. Inline ROOT7da9 additive68pinsverified; certificate/newzero reviews pending. Next bounded highseed loop sixinstructions using rawR0zero saves3 atqerror3 without changingexactq; deadR7residual must be explicit. Then unifiedsource/relinkCPPnearone vs powtable differs only2expadditions, R12/loader/layout/14Bhazard mandatory. Generalmath/totality/physicalcycles/release remainopen; no canonical/Git/device/USB/Flash changes.


Bounded exactseed frozen0a5480ab .build/m0-pow-reciprocal-bound3-20261025, ELF53e62474; sharedunit58764a6b all65536D×16flags1048576tests2097152ARM. Exactq unchanged; error3R7=oldres-D dead beforesecond product, fullaftersecond/laterjoins exact.3355798freshqualifiedARM/157083MPFRinputevaluations+110sNaN(overlappingnotunique); failedhostparent/controlR7mode14184ARM1106MPFR76sNaN excluded,0partialaborts. Same scalar0loss(32387fast1tie); expandedall65536D/two patterns2->0(262132fast12tie),0instructionincreases/no ref filtering. Samepow11369unchanged,10states-3,all77106wrongrefsretained. Code1100->1108(+8),same256Btable/M4/READY9ALU/DIRTY7words;22exactrebuilds;84local2742externalpostsealPASS. Original15333/author438/reviewed422unchanged. Error1 branchdirection changes so no universalcycleGO. Certificate6cfd/ROOTaa392correctness-only/performanceadoptionfalse pinned81directrefs; zero/newbound reviews pending. Unifiedsource phase1 .build/m0-math-unified-source-20261025 nowreal sourcecomposition and8compiledobjects: exp3sections/symbols/relocs matchnear-one, allothersincluding3powcallrelocs matchtableparent,coreASMmatchtable; M0default/M4 exact. Initial hostselectors/wholeobject expectation revised;0ARM/MPFR. NotyetcompleteRPnative/root/square/boundary/reciprocal source or linkedELF/R12/loader/layout/14Bhazard guards. This is nextpriority, not anothermicrooptimization. No canonical/Git/device/USB/Flashchanges.


Unified-source r2 completed and frozen96e5e87f, qualification1d4991b1:
missing add/sub,u32/l2d,ln,atan,sqrtcold now real source in oneELF. Original507
first confirms432strict+6equal+69slow; broad119+53=30136 case evaluations,
60272states,0wrong;196714fresh mathARM combined, overlapping campaigns.
All references retained; broad DIRTY deficits tan/ddiv/asin/acos/pow explicit.

Direct existing Q70 sin/cos source frozen48207d73, qualification8eaa6dc1,
resultf716d5d7 in .build/m0-math-unified-trig-q70-qualification-20261025.
OneELF original507=468strict+6equal+33slow(pow), all36 sin/cos deficits fixed,
saving583..604 instructions. Broad30136/60272states0wrong/0newQfp losses;
193060mathARM plus3654 original507;196714total, campaigns overlap.3756parent
increase execution rows retained, including sharedtan changes. Existing Q70
kernel/argument/gates exact; only RPdispatch/Q62helper sections change,
CPPcode-992B, no new table/RAM/libgcc, hot4080B; M0/M4 objects exact and nine
RP-only disabled units empty on parent. Fresh actual R12+17 controls and
real-ROM source-loader/layout pass. Current broad losing case evaluations:
tan122,ddiv359,asin447,acos364,pow150; these include duplicates and are not
unique args. Original507 is no longer the full remaining-work ledger.
Generalpowtotality, expandedcorpora/newrounding stress, physicalcycles,
canonical integration and release open. No hardware/USB/Flash/Git changes
in this goal turn. Next generic DIRTY division exactsoftwareseed study;
private1/x is not silently generalized. Reviewed422 union remains unchanged.


General public DIRTY normal division source frozen5ad36b06, qualification
403dcb7f, result07692f14 in .build/m0-math-unified-public-div-seed-qualification-20261025.
Exact shared256B seed works for all normal numerators, never assumes R0zero;
1048576actualunit executions(all65536D x16flags) exactfloor/remainder and
preservedR0-R3/R5/R12/SP.24576fullpublic calls(512pairs x16flags x3SIOstates)
match READY/DIRTY/pending R0-R7/R12/SP/NZCV/frame28 aftertheNR/product join;
commonNRsuffix actualallocatedbytes identical toparenthardware path.
Fullbroad119+53/original5070wrong, allREADYcounts exact,0currentparent
increases/0newQfp losses.359DIRTYddiv states save369..466instructions butall
still12..21behindQfp; not performanceGO.196714freshmatrixmath+1048576seed
blocks+24576livejoincalls=1269866qualified ARM executions, separated kinds;
512freshlivejoinMPFR extra; overlapping campaigns notunique inputs.18normal
objects unchanged exceptRPnative and privateSW exporteddataalias; tablebytes
unchanged/noduplicate, hot4080/M4default exact/9disabledempty, actualR12+17
andloaderpass. Current source474/507author-only; reviewed422 unchanged.
Bound3ROOT367a3ab4 acceptedprivatecorrectness-only;77pins freshly verified;
oldZeroLoop retained andbranchcycles/adoptionfalse.1386localhashes acrossall
newr2/Q70/publicseed packets postsealPASS, nohardware/Git/canonical changes.
Nextremaining12..21genericDIRTY instructions, expandedfullmantissa/IEEE tests,
trigmidpoints/floatFMA, othermath/generalpowtotality/physical/release work.


ROOT r2 HOST composition receipt c3fa876e verified locally:146 direct pins/size/hash exact. Reviewed original507 now438=432strict+6equal,69slower(pow33/sin22/cos14), one exact source-built ELF b9abe7be. Earlier separate422 remains historical. Receipt does not accept Q70/public-divider successors, physical cycles, canonical integration or release. Active software-only public normal-divider experiment and boundary qualification are not yet sealed/accepted.


Public divider experiments frozen, not promoted: software source1df5485a/qual9f856e98 has0wrong but116/131072 boundary losses(82newstate losses). Exact actual hardware half-seed(q+1)>>1 with packed R12 sourceac9b0ddc/qual6ba948b4 has0wrong/2580330qualifiedARM,17oldbroad inputs1instruction behind and36denseboundary inputs29..38behind;65408all-exponent/sign/pack-route inputs0wrong/0loss. Rejected floor(q/2) study was never built;45 diagnostic calls allcorrect and excluded. Frozen reports retain all adverse counts, source proof and startup-exclusion annotation correction. Oldcurrent5ad36b06 remains selected. New hidden-bit literal study would fix1instruction only; remaining rare midpoint-path differences need Qfplib seed analysis. No M4/defaultM0/canonical/Git/device change, no whole-goalGO.


Polynomial public normal divider selected as latest private author-qualified candidate: sourcefc96771f/qualfee2fdd9/result3fb38cbe.3,630,954 fresh qualified ARM. Actual15-instruction seed equals Qfplib and exact rational formula for all1,048,576 high words;16517 rational boxes cover full53-bit mantissas. Byte/branch matched numeric paths prove3..6 fewer instructions for every admitted general normal pair. Dense131072 allstrict(5..6saved), all2044 exponents/four signs/eight pack routes65408 inputs0wrong/0loss, broad ddiv359->0loss. Boundary108 parent-increase states retained and still strict vsQfp; primary original507+broad0parentincreases/0newQfp losses. Table288B=oldprivate256+newpublic32, Flash+24B vsimmediatehalfseed parent, hot4080B unchanged. M4/defaultM0 exact,9disabledempty,R12+17/loaderPASS. Reviewed438unchanged; new author474not independentGO. Current broad remaining indexed cases tan122/asin447/acos364/pow83, with321powstate/reference rows; counts are not interchangeable. Historical larger ln/exp sets not replayed here. Next study exact math-only32/16 integer seed for DIRTY quotient callers, preserving READY and M4. No canonical/Git/device/Flash change; full goal active.


Exact DIRTY32/16 helper r2 selected as latest private author candidate: source992572e6/qual9a196dc6/result37b94869.1327930freshqualifiedARM(196714math+1114832integerunit+16384invariants). ExactallN/d32768..65535, old256Btable reused,total288B/hot4080B unchanged,Flash+96B. All primarytan122/asin447/acos364indexed deficits fixed; savings275..350/221..770/221..722 respectively. Remainingprimarypow83indices/321state-reference rows; original33pow and474/507unchanged. All READYmath and4216integer controls retain exact counts,bits/reference costs identical,0wrong/0newQfp losses.25parent increases from3instruction nonzeroDIRTY out-of-domain guard retained. M4/defaultM0 exact,17otherobjectFPexact,9disabledempty,R12+17/loaderPASS. Failedchecker/ABI-driver/READYd0attempts immutable and excluded. New review/largeexpandedcorpora/floatFMA/globalpowtotality/devicecycles/integration/releaseOPEN. Next optimize out-of-domain tail dispatch by removing redundant EABI wrapper, then pow and retained large ln/exp sets. No canonical/Git/device changes; goalactive.


Integer16-r3 direct CPP tail selected as latest private author candidate: source358cf64f/qualfda77481/result77441496/candidateefe043ba. All25primary guard regressions removed, exact leaf/table bytes unchanged;1327930 fresh qualified ARM0wrong, original474/507 and broad83pow remain. All18other object fingerprints and M4/defaultM0 exact,9disabledempty,R12+17/loaderPASS. READY/d0 unchanged; outside16bit domain high16nonzero/bit15set retains+1 vs preinteger parent, explicitly measured. Flash+8B vsr2/+104B vspolynomial; tables288B/hot4080B unchanged. Reviewed438 remains independent scope only. Read-only pow166call profile shows48negative-wide endpoint cases and only3private1/h cases; exact exponent interval gate is a study, not an implemented result. No canonical/Git/device change; goal active.


Negative integer pow endpoint-r5 selected as latest private author candidate: sourceb4f94158/qual6fccd736/resultecf225bb/candidate94f87bbd. Primary48pow losses fixed,610..800instructions saved;35pow indices/185state-reference rows remain. Extra5961MPFR inputs2448parent losing cases->289(1193reference rows), allzero/Inf. Current known union324unique pow argument tuples, historical large pow/ln/exp not included. Zero new correct-reference losses; all32primary and444expanded parent increases retained.494517freshqualifiedARM=286129public+208388private,0wrong. Exact32-bit integer/parity validation, all118916admitted dyadic exponent pairs, full exponent mantissa interval and rational(9/8)^5<2 proofs. Flash+352B vsinteger16-r3; tables288B/hot4080B/globalRAM unchanged. All18otherobjectFP/defaultM0/M4 exact,9disabledempty,R12+17/ROMloaderPASS. Four failed speed revisions immutable, counts not pooled. Original474/507 and independently reviewed438 unchanged. All larger corpora/newrounding/floatFMA/generalpowtotality/independentacceptance/devicecycles/integration/release remainOPEN; no canonical/Git/device change. Next289expanded endpoint admission and35primary pow cases.


ROOT successors receipt7555bbbe arrived after endpoint-r5 sealing: all local direct/transitive pins reverified, existing independently reviewed finite HOST ledger now474(468strict+6equal),33pow. Exact reviewed chain R2->Q70->publicDIV5ad/403d and ELF eb24eeb7; not later polynomial/integer16/endpoint-r5. Frozen r5 field reviewed438 records previously locally verified state and is superseded by this additive receipt note, not rewritten. Universal stack/totality/cycles/main/HIL/adoption remain false.


Generic integer pow endpoint-r7 selected private author: sourceb77da314/qual4e1523be/result1f130920/ELF392a34ae. Old5961all289losses->0; new8240admission744parentlosses->6finite, new1888zeros224parentlosses->114positivezero. Current unique losing union155=35primary+6finite+114positivezero; historical large sets excluded.728281freshARM=438049public+290232private,0wrong,0newcorrectQfplib losses. Allwrongrefs/costs and576primary/13524endpoint/12645admission/1962zero parent increases retained. Source-proved integer log products, rational bounds, dyadic packing and finite-integer negativezero fast path. Flash+136B vsr5, no newtables/globalRAM, tables288B/hot4080B. M4/defaultM0/18otherFPexact,9disabledempty,R12+17/ROMloaderPASS. Rejectedr6immutable699961calls not pooled. Dyadic fast packing is inside e>=4 OR baseE outside959..1086. It handles all finite integer exponents within that admission. Smaller ordinary dyadic inputs retain the previous path. This qualifies the short HANDOFF wording; source/result domain statements are authoritative. Reviewed474 stillolder5ad chain; authorr7notaccepted/main/HIL/deviceGO. Nextcold positivezero pow_refine_checked andremainingfinite/primarypow; globaltotality/largecorpora/rounding/floatFMA/cycles/integration/releaseOPEN.


Positivezero ASM-R9 selected private author: sourceb588ecad/qual54fbe6a9/result3acf7cc1/ELFd4a39879. Existing RP cold-helper zero branch reused,9new instructions/Flash+16B, oldnonzero instructions/branches/literalvalues/calls exact. EntireCPP/18otherobjects/defaultM0/M4 exact; otherRPASMsections exact, no newtable/globalRAM, table288B/hot4080B/frame16B unchanged. All114positivezero deficits fixed,691..814instructions saved; all12288zero-Y exponent-field cases no losses. Current known union41=35primary+6finite admission, historicallargerpow/ln/exp excluded.629857freshARM=622369public+7488private flags,0wrong/no newQfp losses. Inherited290232R7privatecalls not pooled. Primaryallcounts exact/0increases;18zero and18all-exponent rows+3fornonfiniteY remainstrict and retained. Actual16NZCV/3SIO/fullcontext/calleeABI pass; R12+17/ROMloader/9disabledPASS. R8CPPvariant immutable/unselected for1634+1normal rows. Additive Oracle accounting separates exactsNaN shortcuts; mathematical/ARM outputs unchanged. Reviewed474 stillolder5adchain, authorR9notaccepted/main/HIL/deviceGO. Next41powprofile andhistorical ln/exp replay; fullgoalOPEN.


Current41 read-only R9 function profile in .build/m0-pow-current41-profile-r9-seal-r2-20261025,82diagnostic ARM/0MPFR, expectedbits/costs equal current qualifier, not pooled. Private1/h only3cases; main aggregate cost integer128square38804/sqrt64raw25544/approxhigh6417954/base14890/factorpow14590. Initial profile seal contained a live stdout log hash; preserved unchanged as invalid packaging, repaired host-only by copying/reverifying unchanged raw/code/data, no rerun. Current629857math qualification/source packets unaffected.


Current R9 full ln/exp replay frozenc63991fb: ln88589/exp490031 inputs,2314480freshqualifiedARM,578573directedMPFR+47sNaN. Actual same source-linked ELF/realROM/poisonedbankloader; fresh Qfplib each state. 0wrong/0newQfp losses/0parent increases; ln5 and exp214 slower cases retained. Exp42states improve282..1085 instructions vs historical component, all other counts exact. Independent source R9 narrowzero review40fc337e locally verified960pins: narrowHOSTGO under inheritedR7 assumption only, wholeR7/R9 notaccepted. Current measured union260=ln5+exp214+pow41, not wholelibrary count; largerpow/newrounding/floatFMA/totality/cycles/integration/release open. Read-only old219loss profile876ARM/219MPFR separate. Human reciprocal expression1/(1/x)/(1/y) diagnostic75ARM/65MPFR+exactinteger refs:7*.1 direct99instructions vs660, differentRNEbits; subnormalexample underflows expression tozero. Four correctlyrounded divisions do notimplement correctlyrounded multiply. No librarysource/Git/device/port/Flash change; goalactive.


Unselected R10 ln point prototype frozenb8bee21e: sourceELFd69beb18,24237diagnosticARM/2693MPFR,0wrong/0newQfp losses. All5old losses now682..767vs775..797 in3SIOstates. Newneighbor3FF0E23E6966260F already slower inselectedR9:READY2120/DIRTY2175vsQfp781; R10still2286/2351. CurrentselectedR9 knownunion261=ln6+exp214+pow41. Full88589 replay/new source-bound proof/unit pending; R9 remains selected. Only3CPPsections/+660codeB;18otherobjects/M4/defaultM0 exact; no newtable/data/libgcc. Normalparent+17..24 andcoldregressions retained. Next cold-onlyexactcross squareerror refinement; no canonical/Git/device/port/Flash changes.


R12 source4ae96762/qual970bdf7a rejected forspeed. Full91271unionln0wrong,5old fixed,102newQfp losinginputs/103state rows,total103slower. Normalparent180346increase rows retained. Fullpublic561798ARM+exactgate151536=713334freshqualified, diagnostic24237/profile4 notpooled. All1024centers/rationalerror bound/signedwidth+flags+3SIO gateunit pass. Allnonln original507/broad counts exactR9. OnlyRP lncode/+932B, no newtable/RAM/libgcc,M4default exact. SelectedR9known261(ln6/exp214/pow41) unchanged; O2callersR13 beingtested, notselected yet.


Private selectedR14 source9242767e/qual587a248f/ELF3d6dedd1:1215738freshqualifiedARM=1114938public+100800router; R12pointgate151536inherited, diagnostic26253/2917notpooled. Full91316union and92160newadmission0wrong/0newQfp losses. KnownR9ln7->R14ln2:3FF0E23E6966260F and0FF9600000000001; second newlyfound inR9aswell. Allparent79146union/184320admission increases retained; allnonlnprimarycounts exactR9. Original474/507 unchanged,pow41/exp214; knownmeasured257notwholelibrary. R9originalcallers/data/18objects/M4default exact; newrouterordinary9/14,zero6,+Inf8 exact; admittedfamily+3. CPP+4476B,linkedFlash+4480B,0newtable/RAM/libgcc. Olderreview474 andR9finite/narrow receipts nottransferred into wholeR14acceptance. Alllargepow/rounding/floatFMA/generalpowtotality/globalstack/cycles/integration/release remainopen. Next exactln2bias shortcut fornonzeroexponent loss, cheaper smallpositivecoldgate. No canonical/Git/hardware/ports/Flash changes.


Additive R14 hotbank correction frozen1b1a7076: withdraw literal linked scratch_y byte identity in frozen source-binding-proof field. Address/4080B unchanged but20bytes differ:4BL displacements,2Flash pointers,4permuted veneer literals. Allveneer bodies and ultimate symbol targets at allcallsites match; alltarget originobject sections/symbols/relocs exact, exp_table linkedbytes exact. .data/.bssregion claims retained; no runtimeRAMbyteidentity. NoARM/MPFR/builds orparentmutations; oldfinitecounts unchanged, wholeR14notaccepted.


Private selected R15 source2d48d6ba/qual4fcb2be1/ELFd66a8b18: fresh1115966public+17760packers=1133726ARM, inheritedrouter100800/point151536notfresh. Full91573lnunion/92160admission0wrong/0newloss, oldln2->1; target0FF9600000000001 saves1741instr to618/650vs785. Remaining3FF0E23E6966260F830/906vs781. Allparentincreases retained incl0primary/3314ln/18434admission. NonlnprimaryexactR14, original474/507,pow41/exp214 inheritedunchanged; known256notwholelibrary. CPP-100B/Flash-104BvsR14, no newtable/RAM/libgcc/M4defaultchanges; linkedbank7changedbytes semanticallymapped, neverbyteidentity. R14narrowreviewaa2/root43bd locallyverified with inheritedR7/R9/R12assumptions; no wholeR14/R15GO. Previous status-onlygoalturn revalidated by completedln/admission terminaloutputs; no tests restarted. Nextcheapersmallpositivepointgate; all largerpow/rounding/floatFMA/totality/stack/cycles/integration/release open. No canonical/Git/device/USB/Flashchanges.


Private selectedR18 sourceeb8d9ec8/qual2e0d9453/ELF19dd878b: fresh1115966public+113664pointbundle+100800router=1330430ARM, inheritedR12point151536/R15bias17760notfresh. Full91573lnunion+92160family0wrong/0correctQfp deficits, knownln1->0. Lasttarget700/776vs781 (-130vsR15). Allparentincreases retained: 256primary/912ln/0admission. Allnonlnprimarybits/counts exactR15, original474/507; priorpow41/exp214 not universalcounts. Large120980powfreshcurrentR18/R15/3Qfp+MPFR replay separate andlive, knownpowremainderalreadygrows. CPP/Flash+328B/no newtables/RAM/libgcc/M4/defaultchanges; whole672Bunitpointbundlebyteexactproduction, verified table namespacealiasrelocs. Linkedbank17bytesmapped, no literalidentity. R16/R17rejecteddiagnostics immutable/notpooled. No whole-independent/totality/universalstack/cycles/integration/releaseGO; no canonical/Git/device/USB/Flashchanges.


Fresh currentR18largepow sourceeb8d9ec8/campaignc60efd11:120980pairs/1209800ARM/120862MPFR+118sNaN, currentR18/R15counts all241960states equal,0wrong/newvsR15/increases. All3Qfpcompositions eachinput/state, no nominalfilter,261056wrongrefvariants retained. Currentlarge2772slowpairs; union current35primary+inherited6admission=2778pow, exactdedup inunion.json. Old11369 source/refsubset vsnewcurrent/all3 coverage is distinguished, not naivesubtraction; prior41 superseded. Currentknownln0/exp214/pow2778 notwholelibrary/universalrounding/totality/stack/cycles/integration/releaseGO. No canonical/Git/device/USB/Flashchanges.


Unselected R19 exp-shift source02e2ea67/ELF70a43629: exactRP1..21limbshift source proof+7482primitiveARM; separate5806inputs/52254ARM diagnostics0wrong/newloss/increase. Normal-1instr, other0; newneighbors reveal222preexistingselectedR18losses: knownexp214->436, R19fix11->425 incl3old. SelectedstillR18, full490031+newunionqualificationpending. CurrentknownR18ln0/exp436/pow2778=3214notwholelibrary. CPP/Flash+24B/no newtables/RAM/libgcc/M4defaultchanges, actualR12/17/loader/9disabledpass. R15reviewfbd8 directpins locallyverified, narrowinheritedassumptions/no wholeGO. Nextpriority largepow-0.5 route1996/2772large losses and expensiveendpoint251, plusfullR19replay. No canonical/Git/device/USB/Flashchanges.


Private selectedR19 source02e2ea67/qual24c8b9d4/ELF70a43629:full494903exp union0wrong/newloss/increase, known436->425 (11fixed). Fresh2176326public+7482shiftunit=2183808ARM; diagnostic52254/5806separate. Cachedbaselineprovenance historicalR9full/freshR18probe explicitlytagged, notfreshR18full. Primarynonexpallbits/counts exactR18; original474/507, inheritedln0/pow2778. CPP/Flash+24B/no newtable/RAM/libgcc/M4defaultchanges; R12/17/loader/9disabledpass. R18review3ef2 directpinsverified, narrowinheritedassumptions only. Previous statusgoalturn verifiedwait onlive69224, nowterminalconsumed no restarts. Next R20 local Newton rsqrt bound; allglobalrounding/totality/stack/cycles/integration/release open. No canonical/Git/device/USB/Flashchanges.


Private selectedR20 sourcedb648bac/qualac77e0d8/ELFaef4b854:full120986pow freshR20/R19/all3Qfp+MPFR0wrong/newloss,2778->2296 (482fixed). Fresh1406574public+196608primitive=1603182ARM; diagnostic177585/11839MPFR andstudy1996/0newMPFR separate. Allparentincreases retained:4726largepow states(+2:4712/+7:14), primary2. 1908states-432..435instr. Allnonpowprimarybits/counts exactR19; inheritedln0/exp425; original507noslower474. Only14Bguard, ASMallocated+12B/Flash+16B/no newtables/RAM/libgcc, CPP/18others/M4default exact; linkedbank symbolicmapped notliteralidentity. Known2721notwholelibrary; globalrounding/totality/stack/cycles/independent/integration/release open. Q8Newton-rounding model next, preserve ordinaryrsqrt costs. No canonical/Git/device/USB/Flashchanges.


Next Q8 local Newton/rounding model frozend9cf6e3a: .build/m0-pow-rsqrt-q8-study-r18-20261025:purehostexactrationals/newARM0/newMPFR0, saved1632central-word boundarymetadata1619decisionsmatchgold (down969/up650/decline13),1119predictedextraexitsoverR20coarse500. No implemented/measured runtime speed claim. helper-body.inc contains candidate C++frame reader; bind/testbeforeuse. Exact Nerr differs from3*S*beta^2/2^96 by<1/256 (bound1.071e-8); u=absBetaTop8,v=seedTop8 givesQ8Newtonbounds floor(3u²v/65536)-1/ceil(3(u+1)²(v+1)/65536)+1, lowerclamp0. etaQ8 approx top8(low32(Al*Bh))+top8(low32(Ah*Bl))+top8((Al>>16)*(Bl>>16)); exacteta256 lies[eta8,eta8+4). Producteta*S bounds usev/v+1; fracFS top8(low32(Flow*S)); strict E_Q8bounds choose midpoint256*(512-tail), multiply signed256 (no negativeleftshift). Frame:0xlow,1mhigh,3scalehigh,4parity0/1,5Flow(newcapture),6seed,7Fhigh,8Ahigh,9qlo,10qhi. Keep R20coarseexit instructioncounts exact. For extended tails508..514 in centralfactorwords, save rawq atSP36/40 and callhelper withSP pointer; nonzero Ureturn is readyresult,0declines. On decline restoreq then originalexactboundary. Storagebudget canstayneutral WITHOUT privateABI change: original STR xhi->SP8 exists solely for compare==2 fallback. Native lower=0x3fd...+(anyU64q>>10) has exponents-2..1, parity0/1 =>targetbit155..162 alwaysin128..191, so originalboundary return2 is unreachable. Remove that deadcompare/branch/fallback and move the oldxhiSTR to Flow SP20 afterfactor(subtract)beforeF*seed; no other livevalue/flag changes, sameordinary instructioncount. SP20 oldnegative flag is dead afterseedcorrection. Do not readunusedSP8. Preserve standard single-double hiddenfastleaf ABI; no R2-exponent contract required. AddRP-only helper/newsection, CPP+ASMsourcebinding andM4/defaultFPmustmatch, actualR12/17/loader/9disabled guardsrequired. Unitintegerintervals/capturedmetadata and fresh MPFR/Qfp publictests mandatory; retainallparentincreases. SelectedR20 knownln0/exp425/pow2296; rootgoal totality/globalrounding/floatFMA/newstress/universalstack/cycles/integration/release remainsopen.


Private selected R24 source64f2f753/qual881abcd8/authorf743070b/ELF8b51731b: full121286 freshR24/R20/all3Qfp+MPFR0wrong/newloss,2302->1897 (405fixed). New300admissions include6R20-preexistinglosses; old120986/2296 scope stays historical. Fresh1617126qualifiedARM=1409574public+207552gate/context; R22helper204576/quotient227298 inherited/notfresh; focused178350/11810MPFR+80sNaN separate. All17266full parent increases(+1:17222/+99:44) and160broad increases retained. Allnonpow primary bits/reference/owncosts exactR20; original474/507 unchanged. Strictq-3<Y<q+4 rational3cornerproof extends coarse tail508; exactsignsplitproved. CPP+224B/ASM+24BvsR20, no newtables/RAM/libgcc/M4/defaultchanges, linkedbank symbolicmap/no literalidentity. Known2322=ln0+exp425+pow1897 finite, whole rounding/totality/floatFMA/stack/cycles/independent/integration/release OPEN. FrozenRUNNING selected_private_source=R20 is initial baseline only, clarified additively in m0-r24-run-handoff-clarification-20261026.json; authorresult selectsR24. Next math-only subnormal endpoint study773bf87c plusimplementation notes;35old+6new eligible losses, no runtime gain claim. No canonical/Git/device/USB/Flashchanges. Goalactive.


Private selectedR25 source110712b8/qual14ff1728/author9aa804e0/ELF145732d7: full140715freshR25/R24/all3Qfp+MPFR0wrong/newloss,6107->2501 (3606fixed). New19429inputs expose4210R24-preexistinglosses; oldR24full121286/1897scope preserved; oldsubset39fixed/1858remain. Fresh1733224qualifiedARM=1603864public+129360whole-wrapper marker/contextprimitive; diagnostic327495ARM/21133MPFR+700sNaN separate. All4574full increases(+2:782,+7:2648,+9:148,+12:996) retained. Allprimary outputs/reference/owncosts includingpow exactR24; original474/507 and35broadpowcases unchanged. Only RPcoldsection148->188B/Flash+40,no newLUT/RAM/libgcc;18unchangedobjects includeCPP/mergedASM/M4default. Bank3bytes symbolicallymapped, no literalidentity. Known2926=ln0+exp425+pow2501 finite; full rounding/totality/floatFMA/stack/cycles/independent/integration/release OPEN. New exp profilef0c9ba38 in .build/m0-current-exp-loss-profile-r24-20261026:425inputs/850freshdiagnosticARM/425MPFR,0wrong/allcosts exactsavedR19,294refine and131other cases, no source change or pooling. No canonical/Git/ports/USB/device/Flashchanges. Goalactive.

Next exp experiment and all consumed handle IDs recorded in .build/m0-exp-next-directed-bound-20261026.txt. Tiny-y math study98711968 proves318new eligible inputs but0 currentlosses, unimplemented/deprioritized. Existing exp positive-x/below directed bound may extend fromtail511 to509..512 with targetdistance; MUST inspect/rebind original proof and freshR12/M4/full-corpus controls before any claim.


R28 exp PRIVATE sourcedb217c84919e9b5a7e521a8b5328757d852d2121c6086cb255ebc5a35b0a5ce6 proved/notselected: exactfloor+same strictupper all4lowertails. Diagnostic7784/70056ARM479->428losses,51fix0wrong/new; old42543fixed382remain,54newparentpreexisting. SelectedR25nowknownln0/exp479/pow2501=2980FINITE untilfullqualification. CodeFlashdelta0/no newtablesRAMlibgcc/M4defaultchanges; actualR12/17/ROMloader/9disabled and sourceunits pass. RejectedR26/R27 new11/1losses frozen; first coverageassertion failure excluded. Whole goal remains open.


R28 author-qualified sourcedb217c84919e9b5a7e521a8b5328757d852d2121c6086cb255ebc5a35b0a5ce6/qualification0ba57f4e189ef444dc849d8dc42836f2a56ab8780282c36854d320317b42a70b: full494961479->428exp losses/51fix/0wrong/new; old494903425->382,58newinputs54preexisting losses. Fresh4281434qualifiedARM; all114parentincreases retained. Allnonexpprimary bits/ref/owncosts exactR25, exp4..6saved/0primaryincreases; M4default/18others unchanged, Flashcode0/newtablesRAMlibgcc0. Selected PRIVATE R28 knownln0/exp428/pow2501=2929FINITE; R25 fullpow inheritednotfresh. Sourcepending/initialRUNNING snapshots supersededbycompletedqualification. Wholeobjective/CR/totality/floatFMA/stack/cycles/independent/integration/releaseopen; nocanonical/Git/devicechanges.


R29 unselected source c176067a6ba6afda1ff3f158be5c8e148c6bdc8f98dfc0f63dfa86f03f262018/ELF6a0728833c0a3afa306b3e57f8110fd56c9d24a726c8ae8bf16e7b02b9a78c79: exact mainq range and actual669otherinstructions mapped;5->3 normalization, R2/NZCVdead,alltargets/CFGsource closed. Diagnostic7784/70056ARM:428->428,0wrong/new/increases,0/-2counts; core5212->5208/M4default18others exact. R29 qualification full freshcandidate989922 planned (73028), primarymatrix11605; fullMPFR/Qfp inherited from frozenR28 and NOT fresh. Selected R28 remains until terminalR29qualification. No canonical/Git/device changes; whole goal open.


R29 author-qualified sourcec176067a6ba6afda1ff3f158be5c8e148c6bdc8f98dfc0f63dfa86f03f262018/qualificationc1629034ff342e7f7da22d246d360e4548506500a99450d42772107bea4012c5: fresh1186636ARM (989922fullcandidate+196714primary), fullMPFR/Qfp/parentexplicitlyinheritedR28/notfresh. Alloutputs exactR28/qrange and0/-2costmapping,0wrong/new/increases; exp428/pow2501/ln0=2929FINITE unchanged. Core5212->5208/18otherobjectsM4default exact/bank1byte mapped/no newtablesRAMlibgcc; actualR12/17/ROMloader/9disabledpass. Sourcepending/initialRUNNING superseded by completedqualification only. Wholegoal/universalCR/totality/floatFMA/stack/cycles/independent/integration/releaseopen; no canonical/Git/devicechanges.


R30 unselected immutable-index CSE source7c4ea69858bdaa995868aa1b5b70f112315e726f17aeaf719c9049ff6533bfb1/ELF4e5809b442dce441dbb6f34446eb42f72b748dd882b7df6b42c722161160b804 proved. Focus7784/70056ARM428->414/14fix/0wrong/new,all20859increases kept(fastpath+2). Core5208->5192/18othersM4default exact/bank3bytesmapped/no newtablesRAMlibgcc; R12/17/ROMloader9disabledpass. Fullcandidate989922planned95858,primarymatrix48593live; fulloracles/Qfp/parent inherited R29/R28 NOTfresh. SelectedR29 staysuntilterminalqualification. R31 sign-from-k trial rejected51newlosses/FROZEN17482131cc2a34eccb56f91c5c9ed6e81ef85ce10310b38fb7f724510d768a5e, no further qualification. Wholeobjective/CRtotalityFMAstackcyclesindependentreleaseopen,nocanonicalGitdevices.


R30 authorqualified source7c4ea69858bdaa995868aa1b5b70f112315e726f17aeaf719c9049ff6533bfb1/qualificatione94560ca0f4d9a6a3a1148c967807cecd2b9fd8513b116c06c2ccc435eaa6fda: full494961 exp428->414/14fix/0wrong/new; all166416full+2098primary parent increases retained. Fresh1186636ARM (989922fullcandidate+196714primary), fullMPFR/Qfp/parent inheritedR29/R28 notfresh. SelectedPRIVATE R30 finite ln0/exp414/pow2501=2915; core-16/Flash-16/M4default18others exact/no newtablesRAMlibgcc/bank3bytesmapped/actualR12/17/loader9disabledpass. Wholegoal/globalCRtotalityFMAstackcyclesindependentreleaseopen; no canonical/Git/devices.


PRIVATE R33 positive-residual exp bridge author-qualified, no independent/integration GO.
Old494961 inputs414->401/13fix/0new/wrong; expanded union546161 inputs parent627->584, no new speed loss.
All 213 newly discovered losing args preexist in parent; union is not directly comparable to prior smaller corpus.
All full774+boundary1317+primary0 parent increases retained including already-slower; all wrong refs retained/no nominalfilter.
QualifiedARM2683505=public1725172+primitive958333(921901realhelper+36432explicitmarkercontrol).
Fulloracle/Qfp/parent inheritedR30/R29/R28, freshcandidate989922; freshprimary196714+itsMPFR/Qfp; freshboundaries58984MPFR,10240generationlogs excluded; diagnostic70056/7784+loader2 excluded.
Current oldcore5192B onlyoneBLchanged; helper108+bridge104code/Flash+208vsR30, no tablesRAMlibgcc, M4default18others exact, bank21changedbytes mapped.
Actualprivatecaller/source/R12/17/realROMloader9disabled pass. Guard required everychangedreleaseobject. Observed expstack816 notuniversal.
pow2501/ln0 inheritedunchanged; universalCR/generalpowtotality/floatFMA/stack/cycles/independent/integration/main/release remainopen. No canonical/Git/device/USB/Flash changes.
Source FRebdf17a90f34a7d2e5e7d49ac8fd49de47442f1509459bb10b3eb22633b89dd1; qualification FR6cc6994839b641b9496508dcf0181918089835a8327b3f71862ee5cd759c9fde; author04a0dc47dede2d113f873050a1bff2907649eea5181ac7eb8f9fb29272bd6034.


PRIVATE R35 author-qualified row0leaf; no independent/performance/adoption GO.
Old494961 exp401->377/24fix; sameexpanded546161 584->559/25fix,0wrong/new. No new corpus inputs this round. All outputs exactfrozenR33, all correctQfp refs retained/no nominalfilter.
All full326/boundary732/primary0 parent increases retained, +2..11 includingalready-slower; row0 saves64.
Qualified1395844ARM=1372468public(989922full+185832boundaryincl8880row0poison+196714freshprimary)+23376explicitmarkercontrol NOTpublicgold. Realhelper921901 inherited/notfresh. Full/boundary oracle/Qfp/parent inheritedR33; freshprimaryMPFR/Qfp separate, diagnostics70056/7784+failedsyntax0+loader2excluded.
CumulativeR29 every matchingoldfull+primary row saved separately; additional51200 have no R29 remeasurement here. Sums not workloadweighted/cycles and not blanketperformanceGO.
R29full cumulative: net222314instructions, 166432increasedrows, all adverse rows retained.
Only coldbridge104->140B/Flash+40vsR33. Oldcore5192/helper108 and18otherobjects M4default exact, no tablesRAMlibgcc. Bank5mapped/currentobjectcaller+R12+17/realROMloader9disabled pass. Observed expstack816 notuniversal.
All handles consumed terminal: full91236,boundary75205,matrix93383,sourcebuild37562/probe60226/control31283; firstsyntax0ARM preserved inreplay-attempt1. Audit producer terminal beforeseal. R34rejected notpooled.
Finite exp559/pow2501/ln0=3060, not wholelibrary. UniversalCR/generalpowtotality/floatFMA/globalstack/cycles/independent/integration/main/release open. No canonical/Git/device/USB/Flash changes.
SourceFR545ce93e947599e5a1345e04c45aab8b979aa2f4d72dc9b11ed9437c12eb3a98; qualificationFRdf92a59684a5c83363d598859797d03de312c001b6713a45c468c2ee5cf99258; author6570b1a6a063a2adb06ff6f7db4ccd4129e4ec1ba40a56c6ba8bc06ac3aaaa2d.


PRIVATE R36 author-qualified normalized row0 outer cells; NO independent/performance/adoption GO.
Same old494961 exp377->311/66fix; same expanded546161559->493/66fix; freshpower10614 with20 new parent-preexisting losses all20fixed; union546181 parent579->493/86fix/0new/wrong. All wrong Qfp rows and every parent increase retained, no nominalfilter.
Full330/boundary405/freshpower81 parent increase rows(+2..8), primary0. R29cumulative fullnet-54768,166268increased/728decreased/822926same; primary2098 increases remain. Every cumulative row saved; additional51220 have no R29 remeasurement; no workload/cycle/generalperformance claim.
Qualified1516996ARM=1483834public(989922full+201672boundaryincluding24720publicpoison/16NZCV over103inputs+196714freshprimary+95526freshpower)+33162explicitmarkercontrols NOTpublicgold. Full/bound oracle/Qfp/parent inheritedR35/R33/R30/R29/R28; freshpower10614actualMPFR+candidate/parent/Qfp. Realhelper921901 inherited/notfresh. Diagnostics70056/7784,source loader2,generation1log2+2099multiplications excluded.
Onlybridge140->196B/code+56/actualFlash+56vsR35; core5192/helper108/18otherM4default objects exact, no tablesRAMlibgcc; bank5bytesmapped. New actualnormalizedcaller quarter/qAminusP/doubling/kSP8/error6/tailguard and29live audit required everychangedreleaseobject; existing positive/R12/17/realROMloader9disabled alsoPASS. Actual17instruction pack add512 ADDS/ADCS beforeLSR10, normal exponent uses updated k; oldpositiveleaf21preserved. Observedexpstack816 notuniversal.
All source/qual producers terminal: build19859/probe21055/control91988; full87614/boundary22982/matrix87341/prepare23128/powers54286/audit29301 consumed0. Sourceinitialpending superseded only bycompletedqualification. R34 rejected preserved/notpooled. Older R30 and R33 narrow receipts/directpins reverified, no transferGO to R36.
Finite exp493/pow2501/ln0=2994, NOT wholelibrary. UniversalCR/generalpowtotality/floatFMA/globalstack/cycles/independent/integration/main/release remainopen. No canonical handoff/Git/device/USB/Flash/UI/main changes.
SourceFRa60962357af74ab330cb499129dea4f59d79a5887cb1c315a92eef367f283290; qualificationFR738cf0e85797f79a3be8220ed0cf75e2c9f137be020cf86e5d78f43e7ebdd5c2; authord9d9846a776f7f73fc811c8c67954638f94ec81b63c6c4ed299f8b4ffd70656f.


PRIVATE R37 author-qualified small-negative row0 exp shortcut. No independent/performance/adoption/integration GO.
Same old494961 inputs exp311->260/51fix; same prior546181 union493->442/51fix. Fresh10313 edge inputs include10241new and45parent-preexisting new losses; expanded556422 union538->462/76fix,0wrong/new. Forty-five additions are not regressions;20 remain. Current finite ln0/exp462/pow2501=2963, not whole library.
All wrong Qfp outputs/costs and every parent increase retained, no nominal-domain filter. Full70/boundary60/inheritedpower36/freshedge120 increase rows(+3/+6); primary0. Deduplicated adverse state rows220. R29full cumulative net-244412,166156increased/840decreased/822926same. Primary18+2080 increases remain; all cumulative rows retained. Additional61461 inputs have no R29 remeasurement; no workload/cycle blanket speed claim.
Qualified1597537ARM=1525207public(full989922+boundary213912 including36960 public R12/16NZCV poison over154inputs+inheritedpower31842+freshprimary196714+freshedge92817)+72330 explicit-marker bridge controls, NOT public accuracy gold. Full/boundary/power gold/Qfp/parent inherited R36/R35/R33/R30/R29/R28, not fresh. Edges10313 actual directedMPFR plus30939calls each candidate/parent/Qfp; primary MPFR/Qfp separate. Realhelper921901 inherited/notfresh. Diagnostic70056ARM/7784MPFR, source loader2, MPFR generation and failed host audit attempt1(0ARM/MPFR) excluded.
Only coldbridge196->216B/code+20/actualFlash+16 vsR36. Core5192/helper108/tables/other18objects M4default exact, no newtables/RAM/libgcc. Four linked-bank bytes symbolically mapped, not literal identity. Actual unsigned Dlo guard, D=R bound and caller metadata/q/updatedk/error6 live path verified. Positive21/outer paths and normalized17 pack preserved; guards mandatory after each changed release object. Exp stack816 observed, not universal.
Source build18234/probe85316/control18553 terminal0; full16185/boundary30361/power67901/matrix22707/prepare82891 terminal0 consumed; edge7674 nowmissing with completed authoritative result, no restart. Audit13763 terminal0 consumed. Source/initial RUNNING/SESSION pending fields superseded only by completed qualification.
Inherited R30/R33/R35 narrow receipt directpins reverified, no transfer to R37. R36 frozen metadata label error preserved with additive erratum3aba8efa. Audit attempt1 demanded a NaN sign identical to oracle, failed before new ARM/MPFR; original script/log retained. Policy-aware audit still requires exact parent bits and ordinary numeric gold bits.
Whole goal/universal CR/general pow totality/floatFMA/global stack/physical cycles/independent/performance/adoption/integration/main/release remain OPEN. No canonical handoff/Git/device/ports/USB/Flash/UI/main changes.
SourceFR540e32a2a2cac7faa476b08ca792778ea7f327c6c35eb7e73aae7eb5c5f869e7; qualificationFR00dc5efa117f764392cacc06a7d97145ba9cca7650909dd4fc6b68cda5bae8e4; author0d1aa99c40effd3365f20d352c3886b3dcae9f3fd2a0db3093afaf4d19c7573f.


PRIVATE R38 author-qualified midpoint shortcut. No independent/performance/adoption/integration GO.
Same old494961 exp260->248/12fix. Prior R37 qualified556422 union462->447/15fix. Diagnostic156new inputs reveal48 R37-preexisting losses; same augmented556578 union510->491/19fix (15old+4new). Fresh12311inputs include12278new and32new parent-preexisting losses: expanded568856 union542->512/30fix,0wrong/new. Current finite ln0/exp512/pow2501=3013, not wholelibrary.
All correct Qfp results compared without nominalfilter; wrong outputs/costs and EVERY parent increase retained. full:30 increases; boundary:6 increases; power:30 increases; edge:69 increases; admission:48 increases; fresh-edge:75 increases; primary0. CumulativeR29full net-284970, increased166132/decreased864/same822926. Primary18+2080 increases remain. All cumulative rows retained; additional73895 inputs have no R29 remeasurement. No workload/cycle blanket speed claim.
Qualified1740673ARM=1604695public(full989922+boundary213912+power31842+edge30939+admission30567+primary196714+freshedge110799)+135978explicit-marker controls NOT public accuracy gold. Boundary/admission include41520 public R12/16NZCV poison over173inputs. Five replay gold/Qfp/parent sets inherited R37 qualification or frozen R38 diagnostic, NOT fresh. Freshedges12311 directedMPFR and36933calls each candidate/parent/Qfp; primaryMPFR/Qfp separate. Source diagnostic78021ARM/8669MPFR, loader2, MPFRgeneration excluded; realhelper921901 inherited/notfresh.
Only bridge216->232B, code/actualFlash+16vsR37. Core5192/helper108/tables/other18 M4/default objects exact, tablesRAMlibgcc0. Linkedbank4bytes symbolically mapped, not identity. Eight instructions after inner decline, Dhi=-1/Dlo residue2 implies the old unsigned bound; strict249/1000<V-q<1751/1000 decides tail512 upward. Actual caller proves q even/error6/ambiguity1,3,5,7,9 and no metadata clobber. Positive21/outer/inner paths and normalized17 pack preserved. Current-object guards mandatory eachchangedrelease. Stack816 observed, not universal.
All source/full/auxiliary/primary/fresh/audit producers terminal; exact evidence in producer-terminal.json. R38 frozen source NUMERIC-PROOF diagnostic subset count12/7 was mistaken: actual15/4, total19 unchanged. Additive correction49abbcd4 preserved without modifying frozen bytes; mathematical theorem/code/controls unaffected. Failed inline host admission assertion before ledger/output0ARM/MPFR recorded in correction. Inherited R30/R33/R35 narrow receipt pins and R36 metadata label erratum rechecked; no transferred R38 GO.
Whole CR/generalpowtotality/floatFMA/globalstack/physicalcycles/independent/performance/adoption/integration/main/release remain OPEN. No canonical handoff/Git/device/ports/USB/Flash/UI/main changes.
SourceFRda406f31b39e0a01ee415a1ee9d2658d1fbed5ac5ceb04784dc8a25e146a60a2; qualFRaff1d6e8bdedba0bb05cf65d5f3a6f3964da1def390bfed69d28078577797f7a; author92d576275176e25d244d5c2e2facbc45278f98ede54329ae66e8150a43ff227e.


PRIVATE R40 author-qualified early-Q8 pow helper. No independent/performance/adoption/integration GO.
Same140715 fullpow pairs freshcurrentR38/R40/3Qfp/MPFR:2501->2425/76fix,0wrong/new/parentincrease. Diagnostic admission10560 includes4528 new inputs and22R38-preexisting losses; joined parent2523->2446/77fix(76old+1new),21newremain. Primary adds0 nonlosing inputs and no extra losses. Known finite pow2446/exp512/ln0=2958, notwholelibrary. Exp/ln full qualifications explicitly inherited R38, notfresh.
All correct Qfp compositions compared/no nominalfilter. Every wrong output/cost and every parent delta retained. Full freshR38 costs/refoutputs/refcorrectness all exacttaggedR25, not presumed. Parent increases0 full/admission/primary. Full net instruction delta-92646; admission net-68454, notworkloadweighted/cycles. Existing R38/R29 full-exp166132 increasedrows and primary18+2080 remain visible via pinned full cumulative rows; no fresh full-exp replay. Current primary allbits/ref/owncounts exactR38 so its cumulative primary rows remain exact.
Qualified1921664ARM=1635544public(1407150full+31680admission+196714primary)+286120helpercontrols NOT publicaccuracygold. Full140715 pair oracles and currentR38/R40/all3Qfp are fresh: actualdirectedMPFR139899+sNaNpolicy816. Admission candidatefresh only; gold/R38/Qfp inheritedfrozenR40diagnostic, notfresh. PrimaryMPFR/Qfp separate. Source diagnostic158400ARM/10546MPFR+14sNaN, R38profile13752ARM/1146MPFR, R39unselected286120controls, sourceROMloaders excluded.
Only RP Q8 helper section changed;224bytes remains224/codeFlashdelta0/no newtableRAMlibgcc. Other18objects including M4/default/nativeASM exact. Linkedbank16changedbytes symbolically mapped, notidentity. Exact originalintegerformula retained; PL>=0 certifies earlydown, eta<=765 gives PU<=3(v+1)+1 certifies earlyup and U-L>=2 preservesdown-firstpriority. All12actual CFGpaths no slower than old matchingresultdirection. OrdinaryAAPCS R4-R11/SP/frame readonly, LRtarget withsavedreturn, full64packcarry. Mandatory current-object guards and R12/17negative/realROMloader9disabled PASS. Stack bound observed only, universalstackopen.
All producers terminal consumed; exact handles inproducer-terminal.json. Sourceinitialpending/RUNNING superseded only bycompletedqualification. R35 narrow receipt/directpins reverified as historicalscope, no transferredR40GO. SourceR39 preservedunit-only/unselected/notpooled. No frozenartifact modifications, canonicalhandoff/Git/device/USB/Flash/UI/main changes.
Whole CR/generalpowtotality/floatFMA/globalstack/physicalcycles/independent/performance/adoption/integration/main/release remain OPEN.
SourceFR812014c33e9c813c8e83af276c48ca7c61262b380548d0cbde260ad53593ef96; qualFR5c68ca7237922e2f2f15c91f008299f087adc6a8e3932d80530822d1593fa9ac; authord71fecb431e24b3a4019af586ece65243ad26339ebcd5247ad2ad9560f4e0e53.


PRIVATE R41 author-qualified negative-first Q8. No independent/performance/adoption/integration GO.
Same old140715 powpairs:2425->2312/113fix. Same prior145243 union2446->2333/113fix. Extra38diagnostic inputs expose9preexisting R40losses, all9remain; expanded145281 parent2455->2342/113fix,0wrong/new/publicparentincrease. Known finite pow2342/exp512/ln0=2854, notwholelibrary. Exp/ln inheritedR38/R40/notfresh.
All correct Qfp references retained/no nominalfilter; wrong outputs/costs and EVERY public/control cost increase retained. Fullnet-29444/admissionnet-22572 instructions, notworkloadweighted/cycles. Publicparentincreases0. Qualifiedsynthetichelpercontrols3591increases(+34/+35), allseedtopbytes0..82; actualnative prefix provesv>=127, where every tested/helperpairedpath has0increases. Controls are not publicnumericgold and their adverse rows remain in frozen source, not discarded.
Qualified796706ARM=509938public(281430full+31794admission+196714primary)+286768helpercontrols. Fullgold/R40/all3Qfp inherited frozenR40qualification, NOTfresh; admissiongold/R40/Qfp inheritedfrozenR41diagnostic, NOTfresh. PrimaryMPFR/Qfp arefresh separately. Source diagnostic158970ARM/10584MPFR+14sNaN excludedpool; inheritedR40full139899MPFR/816sNaN notfresh; sourceROMinitializers excluded.
Primaryallbits/refunchanged, nonpowowncounts exactR40. Original507 allcosts0delta; broad60270rows0 and2powrows-10. Sameprimaryclassification counts retained. Fresh primary cumulativeR29 allrows saved: original increased18/net22; broad increased2080/net4330. Inherited full-expR29/R38 adverse166132rows still pinned, nofreshfull-exp replay/no blanket speedGO.
Only RP Q8 helper changed:224B remains224B/codeFlashdelta0. The512constant uses code/literalpool space, no newlookup/RAM/libgcc. Other18 M4/default/nativeASM objects exact; bank9bytes symbolicallymapped, notidentity. ExactsameQ8formula; positiveearly cost0/positivefull-2/zero-10/negativeearly-18/negativefull-1 vsR40. Actualnative integerseedbound2144340736 givesv>=127,L0<=-130 sozeroearlyup impossible. All36pairedlogicalCFG cases boundtoactualISA; BMIreadsactualtargetLSLSN withMOVLRpreservingflags. OrdinaryAAPCS R4-R11/SP/frame read-only, full64carry. Explicitcarryup180controlrows. Extra literal load needs physicalcycle acceptance; no hardware timing claim.
All source/replay/primary/audit producers terminal consumed; exact handles inproducer-terminal.json. Initial sourcepending/RUNNING snapshots superseded only bycompletedqualification. R35narrowreceipt/directpins reverified as historicalscope, no transferR41GO. No canonical handoff/Git/device/ports/USB/Flash/UI/main changes. Observedpowstack2284 is notuniversal.
Whole CR/generalpowtotality/floatFMA/globalstack/physicalcycles/independent/performance/adoption/integration/main/release remain OPEN.
SourceFRa7d40e058c905f614b5404f509041c1d640c4bfaa8483244ec6dc310bb51197f; qualFRaa13981ded8055e02cd9c4fb5ee3106bc200e1210ce72bba1e5688aa32a55884; authorf2cf8c86ee391e674ffa04cc11bbb1df34a3243e4b1a41518d3c9d0f7fa97c51.


PRIVATE R42 author-qualified dead-register seed reuse. No independent/performance/adoption/integration GO.
Same140715full pow2312->2303/9fix. Sameprevious145281union2342->2327/15fix. Additional6128inputs expose26preexistingR41losses, all26remain; expanded151409parent2368->2353/15fix,0wrong/new/publicparentincreases. Knownfinite pow2353/exp512/ln0=2865, NOTwholelibrary. Exp/ln inheritedR38/R41/notfresh.
All3correctQfp compositions retained/no nominalfilter; wrong outputs/costs and everyparent delta retained. Fullnet-104946/admissionnet-45714instructions. Allnew public and product-control parentincreases0. PriorR41synthetic helper3591increases remain in pinnedR41source, NOTfreshR42parentincreases/publicnumericcases. Allinheritedexp/R29adverse166132rows still pinned/notfresh replay; no workload/cycle blanketclaim.
Qualified620386ARM=528364public(281430full+50220admission+196714primary)+92022actualintegerproductcontrols NOTpublicaccuracygold. Fullgold/R41/all3Qfp fromfrozenR41qualification, admissiongold/R41/Qfp fromfrozenR42diagnostic, NOTfresh. CandidateR42full/admissionfresh; primaryMPFR/Qfpfreshseparately. Source diagnostic251100ARM/16726MPFR+14sNaNpolicy EXCLUDEDpool; allpriorARM/MPFR andsourceROMinitializers excluded.
Primaryallbits/ref unchanged; every nonpowcost exactR41. Original507952rows0/62powrows-1; broad60174rows0/98powrows-1. Classificationsunchanged original474noSlower(468strict+6equal)/33powremain; broad23939strict/5888noCorrectRef/274equal/35powremain. FreshcumulativeR29 allrows saved: originalinc18/net-40, broadinc2080/net4232. Existingadverse rows retained, not general speedacceptance.
OnlyRPASM rsqrtproductsection changed, other18objects M4/default/CPPexact. R6's lastcarry use precedesnewseeddefinition, and oldsuffix hasnoR6reads exceptrestore. Actual388->387reachableISA,10operandrenames andone removedLDR, allbranches/literals/edges paired. Every8unprunedproductCFGpath-1instruction, onefewerSP24read; exactuint96integerformula unchanged. Freshpublicpointq/liveframe/R5Bh/completeQ8frame exactparent. Native808B/helper224B/Flash492408Bunchangedduetobalignment; bank4080Bliterallyidentical, all tables/no newRAM/libgcc. Actualcurrentexp/R12/17negative/normalized/realROMloader9disabled guardsPASS andmandatoryeachchangedrelease. No physicalcycle claim.
All source/full/admission/primary/audit handles terminal consumed; exactproducer-terminal.json. R35narrowreceipt/directpins reverified historicalonly, no transferR42GO. Observedpowstack2284 notuniversal. WholeCR/generalpowtotality/floatFMA/globalstack/physicalcycles/independent/performance/adoption/integration/main/release OPEN. No canonicalhandoff/Git/device/USB/Flash/ports/UI/SDK/main changes.
SourceFRb5e0bf1e6316a2bc0924127f0b9564c025cb042842f4d3527ce1eef8fd48a676; qualFRc9e7ebb1dcd34a4536e12fcb77af95ecbfc51f44176fe5b7e57e85b7cbe39515; authora36482a4e77d0db741339e68e1620121e76c4ceb35f356c4047641d5ef206405.


PRIVATE R43 author-qualified separate native Q8 carry entry. No independent/performance/adoption/integration GO.
Samefull140715pow2303->2293/10fix; sameprior151409union2353->2343/10fix; no new corpus inputs or newly exposed losses. ln0/exp512 explicitly inherited R38/R42. Knownfinite pow2343+exp512=2855 NOTwholelibrary. Public0wrong/new/parentincreases. All3correct Qfp compositions retained/no nominalfilter; wrong outputs/costs and EVERY parent delta preserved.
Qualified1101900ARM=528364public(281430full+50220admission+196714primary)+573536helpercontrols/explicitdisjointnativefixtures NOTpublicnumericgold. Full/admissionR43candidatefresh, R42/Qfp/MPFR cached explicitlyfromfrozenR42qualification/R43diagnostic, NOTfresh. PrimaryMPFR/Qfpfreshseparately. Source diagnostic251100ARM/16726MPFR+14sNaNpolicy EXCLUDEDpool; allpriorARM/MPFR andROMinitializers excluded. Genericcontrols143384increases(+2) ALLretained, nativefixture0increase(-1each). PriorR41synthetic3591adverse controls remain historical/notfresh.
All13unprunednativeCFGpaths-1instruction; all13genericpaths+2retained. NativeentryexplicitCprecondition fromuniqueCMPdelta,1guard, BHI/3STR/MOVsp/BL/PUSH/MOV preserveC toSBCmask. ActualCchecked everypublic/helperfixturecall; ordinarygeneric entry keepsarbitraryNZCV. Bothentrysourceinstructions/branches/literalsbound. New mandatorycurrentobjectCguard+12negatives, inheritedexp/R12/17negative/normalized/realROMloader9disabledPASS; guardsrequired aftereverychangedrelease. ExactintegerQ8formula/pointq/liveframes/BhR5 unchanged;180full64carryupcontrolrows. OrdinaryAAPCS R4-R11/SP/frame readonly/SIOexact.
OnlyRPCPPhelpersection224->232B, actualFlash+8; nativeentrysymbol220B. RPASMallocatedbytesexact, oneBLsemanticrelocation changed. Other17M4/defaultobjects exact; no newtablesRAMlibgcc. Target512Flashread removed, replacedby2ALU. Bank13bytes symbolicmapped, not literalidentity. Physicalcycles NOTmeasured.
Primaryoutputs/ref exactR42, allnonpowcostexact. Original507all1014rows0delta; broad60270rows0/2powrows-1. Classificationsunchanged474noSlower468strict6equal/33pow and broad23939strict/5888noCorrectRef/274equal/35pow. FreshcumulativeR29allprimaryrows retained: original18increases/net-40; broad2080increases/net4230. Inheritedfull-exp/R29 adverse166132rows pinned/notfresh; no workloadweighted/general speedclaim.
Allsource/full/admission/primary/audit handles terminal consumed. FirstdisabledmetadataaliasKeyError preserved in controls-attempt1 withoriginalreport/logs; addedalias for alreadyprovedM4fingerprints, no rebuild or numeric change; finalguardsPASS. R35narrowreceipt/directpins reverified historicalonly/no transferR43GO. Observedpowstack2284 NOTuniversal. WholeCR/generalpowtotality/floatFMA/globalstack/physicalcycles/independent/performance/adoption/integration/main/release OPEN. No canonicalhandoff/Git/device/USB/Flash/ports/UI/SDK/main changes.
SourceFR170cd77a62244459c526ea2817f964652f4355c31e7824defc7b0195a6a5b22b; qualFRebef878da8240173c273bb9e31b02c0a55c48e75286a7fe0dcc800c3c2130786; authorbd7070031026d66992dd0f695e2d0b0e9fd86d33e97c66fa26e28fe7c6064fa5.


PRIVATE R45 author-qualified exact division overflow. NO independent/performance/adoption/integration/HW/main GO.
Samefull140715pow2293->1997/296fix; same151409union2343->2047/296fix. Newexpanded division20182uniqueinputs (60546uniquestate rows,60912actual source state evaluations): R43parent9061->148/8913fix. These9061include new measuredpreexistingR43losses, not regressions. Current known finite operation-arguments pow2047/ddiv148/exp512/ln0=2707 NOTwholelibrary. 0wrong/0newcorrectQfploss on allqualifiedfinite sets.
AllcorrectQfp results retained/no nominalfilter; wrong outputs/costs and EVERYparentdelta retained. Powfull84/admission30 increase rows; sourceddivdirect1212/grid17046increase rows, including already-slowercases. Exp/ln/primary0. SourceR45ddivMPFR/Qfp/parentfresh once; sourcepow251100ARM/16726MPFR+14sNaN executiondiagnostic excludedpool, gold reusedexplicitly foradmission. R44unselected25758ARM/R43baseline10440ARM/allpriorcontrols/ROMinitializers excluded. No workloadweighted/physicalcycle generalclaim.
Qualified2296597publicARM=2113861freshqualification-stage(281430fullpow+50220admitpow+196714freshprimary+1224907dedupfull-exp+360590dedupfull-ln)+182736sourcepublicdivisioncalls includedONCE (direct25758+grid156978). No new primitive-control calls inpool. Source division oracleevaluations20270actualMPFR+34sNaN include122overlapping inputevaluations, not20270unique inputs. uniqueuniondivisioninputs20182. Fullpow/admissionparentR43/gold/Qfp cached; full-exp parentR38/gold/Qfp andfull-ln parentR18/gold/Qfp cached, as previouslyinheritedR43, NOTfresh. FreshprimaryMPFR/Qfp separate. InheritedR43Q8controls573536/generic143384adverserows andR41synthetic3591 retained/notfresh.
Full-exp568856inputs/1224907uniquestates plus67688duplicateR38rowschecked, candidatebits/countsexactR38,512losses unchanged; all4changeddivisionentryvisits0. Full-ln180295inputs/360590states plus6876duplicateR18rowschecked, bits/countsexactR18,0losses; all4divisionentryvisits0. Primaryalloutputs/refs/costsexactR43 on196714freshcalls; original507474noSlower(468strict6equal)/33pow, broad23939strict/5888noCorrectRef/274equal/35pow unchanged. FreshcumulativeR29allprimaryrows saved:original18increases/net-40,broad2080increases/net4230. Full-expR29adverse166132rows pinned; freshR45oldfullcostsexactR38 revalidatecurrentcumulativevalues, nofreshR29calls.
Source exactCPP e>1023 after finite nonzero quotient normalization returns signedInfinity, boundary arithmetic unchanged. ASM onlynormalnumerator/subnormaldenominator rejection uses exactN<=floor(M/2^(1025-Ea)), bounds/carry/zero/sign/flag-chain verified. Declines preserveargs; fastreturnexisting20byteframe; no newcalls/SIO/lookup/RAM/libgcc. Sourceeditsreversed toR43. Only2RPobjects changed,17others M4/default exact. Flash+104bytes, bank4080same/6bytes symbolicallymapped, notidentity. Mandatorycurrent newdivguard6negatives, nativeQ8Cguard12negatives, exp/R12/17negative/normalized/realROMloader9disabledPASS.
All source/fullpow/admission/primary/exp/ln/audit handles terminal consumed beforeseal. R35narrowreceipt/directpins reverified historicalonly, no transferredR45GO. FirstR43baseline selfsealedlog mismatch preserved; accepted terminalr2reissue no rerun/doublecount. Sourcehostguard BHS/BCS aliasfirstattempt preserved,0ARM/nobinarychange. Observedstacks pow2284/exp816/ln664 notuniversal. UniversalCR/generalpowtotality (__builtin_trap remains),floatFMA/globalstack/physicalcycles/independent/adoption/integration/main/release remain OPEN. No canonicalhandoff/Git/device/USB/Flash/ports/UI/SDK changes.
SourceFRdbc455078837507acaeb750df1e3fb6800b923e2a9a880c9c6bcc2150ba3527a; qualFRe3f2df20d066f085a82722c3f601625e27bf51d070d21659bfeb40fdc270da30; authord318cdb28ae0807c3b43a8d89b6e5cd4cdfc0a7c728ce7a681fcd091ebf398a0.
