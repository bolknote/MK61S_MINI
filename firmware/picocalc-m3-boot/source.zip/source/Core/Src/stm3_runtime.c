#include "stm3_runtime.h"
#include "m3b_entry.h"
#include "protocol.h"
#include <string.h>
static uint32_t get32(const void* p){const uint8_t*s=(const uint8_t*)p;return (uint32_t)s[0]|(uint32_t)s[1]<<8|(uint32_t)s[2]<<16|(uint32_t)s[3]<<24;}
static void put32(void*p,uint32_t v){uint8_t*s=(uint8_t*)p;for(unsigned i=0;i<4;++i)s[i]=(uint8_t)(v>>(8*i));}
static uint32_t now(stm3_runtime*r){return r->backend.micros?r->backend.micros(r->backend.context):0;}
#if defined(STM32F103xB)
#include "stm3_crc_f103.h"
uint32_t stm3_crc32(const void*data,size_t n){return stm3_f103_crc32(data,n);}
#else
uint32_t stm3_crc32(const void*data,size_t n){
 static uint32_t table[256]={
 0x00000000u,0x77073096u,0xee0e612cu,0x990951bau,0x076dc419u,0x706af48fu,0xe963a535u,0x9e6495a3u,
 0x0edb8832u,0x79dcb8a4u,0xe0d5e91eu,0x97d2d988u,0x09b64c2bu,0x7eb17cbdu,0xe7b82d07u,0x90bf1d91u,
 0x1db71064u,0x6ab020f2u,0xf3b97148u,0x84be41deu,0x1adad47du,0x6ddde4ebu,0xf4d4b551u,0x83d385c7u,
 0x136c9856u,0x646ba8c0u,0xfd62f97au,0x8a65c9ecu,0x14015c4fu,0x63066cd9u,0xfa0f3d63u,0x8d080df5u,
 0x3b6e20c8u,0x4c69105eu,0xd56041e4u,0xa2677172u,0x3c03e4d1u,0x4b04d447u,0xd20d85fdu,0xa50ab56bu,
 0x35b5a8fau,0x42b2986cu,0xdbbbc9d6u,0xacbcf940u,0x32d86ce3u,0x45df5c75u,0xdcd60dcfu,0xabd13d59u,
 0x26d930acu,0x51de003au,0xc8d75180u,0xbfd06116u,0x21b4f4b5u,0x56b3c423u,0xcfba9599u,0xb8bda50fu,
 0x2802b89eu,0x5f058808u,0xc60cd9b2u,0xb10be924u,0x2f6f7c87u,0x58684c11u,0xc1611dabu,0xb6662d3du,
 0x76dc4190u,0x01db7106u,0x98d220bcu,0xefd5102au,0x71b18589u,0x06b6b51fu,0x9fbfe4a5u,0xe8b8d433u,
 0x7807c9a2u,0x0f00f934u,0x9609a88eu,0xe10e9818u,0x7f6a0dbbu,0x086d3d2du,0x91646c97u,0xe6635c01u,
 0x6b6b51f4u,0x1c6c6162u,0x856530d8u,0xf262004eu,0x6c0695edu,0x1b01a57bu,0x8208f4c1u,0xf50fc457u,
 0x65b0d9c6u,0x12b7e950u,0x8bbeb8eau,0xfcb9887cu,0x62dd1ddfu,0x15da2d49u,0x8cd37cf3u,0xfbd44c65u,
 0x4db26158u,0x3ab551ceu,0xa3bc0074u,0xd4bb30e2u,0x4adfa541u,0x3dd895d7u,0xa4d1c46du,0xd3d6f4fbu,
 0x4369e96au,0x346ed9fcu,0xad678846u,0xda60b8d0u,0x44042d73u,0x33031de5u,0xaa0a4c5fu,0xdd0d7cc9u,
 0x5005713cu,0x270241aau,0xbe0b1010u,0xc90c2086u,0x5768b525u,0x206f85b3u,0xb966d409u,0xce61e49fu,
 0x5edef90eu,0x29d9c998u,0xb0d09822u,0xc7d7a8b4u,0x59b33d17u,0x2eb40d81u,0xb7bd5c3bu,0xc0ba6cadu,
 0xedb88320u,0x9abfb3b6u,0x03b6e20cu,0x74b1d29au,0xead54739u,0x9dd277afu,0x04db2615u,0x73dc1683u,
 0xe3630b12u,0x94643b84u,0x0d6d6a3eu,0x7a6a5aa8u,0xe40ecf0bu,0x9309ff9du,0x0a00ae27u,0x7d079eb1u,
 0xf00f9344u,0x8708a3d2u,0x1e01f268u,0x6906c2feu,0xf762575du,0x806567cbu,0x196c3671u,0x6e6b06e7u,
 0xfed41b76u,0x89d32be0u,0x10da7a5au,0x67dd4accu,0xf9b9df6fu,0x8ebeeff9u,0x17b7be43u,0x60b08ed5u,
 0xd6d6a3e8u,0xa1d1937eu,0x38d8c2c4u,0x4fdff252u,0xd1bb67f1u,0xa6bc5767u,0x3fb506ddu,0x48b2364bu,
 0xd80d2bdau,0xaf0a1b4cu,0x36034af6u,0x41047a60u,0xdf60efc3u,0xa867df55u,0x316e8eefu,0x4669be79u,
 0xcb61b38cu,0xbc66831au,0x256fd2a0u,0x5268e236u,0xcc0c7795u,0xbb0b4703u,0x220216b9u,0x5505262fu,
 0xc5ba3bbeu,0xb2bd0b28u,0x2bb45a92u,0x5cb36a04u,0xc2d7ffa7u,0xb5d0cf31u,0x2cd99e8bu,0x5bdeae1du,
 0x9b64c2b0u,0xec63f226u,0x756aa39cu,0x026d930au,0x9c0906a9u,0xeb0e363fu,0x72076785u,0x05005713u,
 0x95bf4a82u,0xe2b87a14u,0x7bb12baeu,0x0cb61b38u,0x92d28e9bu,0xe5d5be0du,0x7cdcefb7u,0x0bdbdf21u,
 0x86d3d2d4u,0xf1d4e242u,0x68ddb3f8u,0x1fda836eu,0x81be16cdu,0xf6b9265bu,0x6fb077e1u,0x18b74777u,
 0x88085ae6u,0xff0f6a70u,0x66063bcau,0x11010b5cu,0x8f659effu,0xf862ae69u,0x616bffd3u,0x166ccf45u,
 0xa00ae278u,0xd70dd2eeu,0x4e048354u,0x3903b3c2u,0xa7672661u,0xd06016f7u,0x4969474du,0x3e6e77dbu,
 0xaed16a4au,0xd9d65adcu,0x40df0b66u,0x37d83bf0u,0xa9bcae53u,0xdebb9ec5u,0x47b2cf7fu,0x30b5ffe9u,
 0xbdbdf21cu,0xcabac28au,0x53b39330u,0x24b4a3a6u,0xbad03605u,0xcdd70693u,0x54de5729u,0x23d967bfu,
 0xb3667a2eu,0xc4614ab8u,0x5d681b02u,0x2a6f2b94u,0xb40bbe37u,0xc30c8ea1u,0x5a05df1bu,0x2d02ef8du
 };
 const uint8_t*p=(const uint8_t*)data;uint32_t v=~0u;
 while(n--)v=(v>>8)^table[(v^*p++)&255u];return ~v;
}
#endif
void stm3_init(stm3_runtime*r,const stm3_backend*b){memset(r,0,sizeof(*r));r->backend=*b;}
static void fault(stm3_runtime*r,uint32_t e){r->error=e;r->state=STM3_FAULT;}
static uint32_t invoke(stm3_runtime*r,unsigned operation){
 stm3_api api={STM3_ABI,sizeof(stm3_api),r->backend.micros,r->backend.context};
 const uint32_t before=now(r);
 const uint32_t result=r->backend.invoke(r->backend.context,r->entry,operation,&api,&r->job);
 const uint32_t took=now(r)-before;
 if(took>r->max_slice_us)r->max_slice_us=took;
 // Cooperative modules: this detects an overrun after return, not a sandbox.
 if(took>r->header.slice_us){fault(r,STM3_E_TIME);return STM3_INVALID;}
 if(r->job.output_bytes>r->header.output_limit||r->job.output_bytes>STM3_IO_CAPACITY){fault(r,STM3_E_MODULE);return STM3_INVALID;}
 return result;
}
static uint32_t commit(stm3_runtime*r){
 stm3_header h;
 if(r->state!=STM3_LOADING||r->received!=r->package_bytes)return STM3_E_STATE;
 memcpy(&h,r->arena.bytes,sizeof(h));
 if(stm3_crc32(&h,60)!=h.header_crc)return STM3_E_CRC;
 if(h.magic!=STM3_MAGIC||h.header_bytes!=64||h.package_bytes!=r->package_bytes||h.flags)return STM3_E_FORMAT;
 if(h.abi!=STM3_ABI||h.target!=STM3_TARGET)return STM3_E_ABI;
 if(h.image_bytes<4||h.image_bytes>STM3_IMAGE_CAPACITY||h.bss_bytes>STM3_IMAGE_CAPACITY-h.image_bytes||h.reloc_count>STM3_RELOC_LIMIT)return STM3_E_SIZE;
 if(h.package_bytes!=64+h.image_bytes+4*h.reloc_count||!(h.entry_offset&1)||((h.entry_offset&~1u)>=h.image_bytes))return STM3_E_FORMAT;
 if(!h.input_limit||h.input_limit>STM3_IO_CAPACITY||!h.output_limit||h.output_limit>STM3_IO_CAPACITY||h.stack_hint>512||!h.slice_us||h.slice_us>2000)return STM3_E_SIZE;
 if(stm3_crc32(r->arena.bytes+64,h.package_bytes-64)!=h.payload_crc)return STM3_E_CRC;
 const uint32_t base=r->backend.load_address(r->backend.context,r->arena.bytes),memory=h.image_bytes+h.bss_bytes;
 if((base&3)||base>UINT32_MAX-memory)return STM3_E_FORMAT;
 const uint8_t* relocs=r->arena.bytes+64+h.image_bytes;
 uint32_t previous=0;
 for(uint32_t i=0;i<h.reloc_count;++i){
  const uint32_t at=get32(relocs+4*i);
  if((at&3)||at>h.image_bytes-4||(i&&at<=previous))return STM3_E_FORMAT;
  const uint32_t value=get32(r->arena.bytes+64+at);
  if(value<STM3_LINK_BASE||value-STM3_LINK_BASE>memory)return STM3_E_FORMAT;
  previous=at;
 }
 // Relocations remain beyond the old image while the image is moved down.
 memmove(r->arena.bytes,r->arena.bytes+64,h.image_bytes);
 for(uint32_t i=0;i<h.reloc_count;++i){const uint32_t at=get32(relocs+4*i);put32(r->arena.bytes+at,base+(get32(r->arena.bytes+at)-STM3_LINK_BASE));}
 memset(r->arena.bytes+h.image_bytes,0,h.bss_bytes);
 memset(r->input,0,sizeof(r->input));memset(r->output,0,sizeof(r->output));
 r->header=h;r->entry=base+h.entry_offset;r->state=STM3_READY;r->error=0;
 if(r->module_id==UINT32_MAX){fault(r,STM3_E_MODULE);return STM3_E_MODULE;}
 ++r->module_id;return STM3_OK;
}
static uint32_t check_job(stm3_runtime*r,const uint8_t*in){
 if(r->state!=STM3_READY&&r->state!=STM3_FINISHED&&r->state!=STM3_CANCELLED)return STM3_E_STATE;
 if(get32(in)!=r->module_id)return STM3_E_MODULE;
 if(get32(in+4)>r->header.input_limit||!get32(in+8)||get32(in+8)>10000)return STM3_E_SIZE;
 if(r->job_id==UINT32_MAX)return STM3_E_JOB;
 return STM3_OK;
}
static uint32_t start_job(stm3_runtime*r,const uint8_t*in){
 const uint32_t error=check_job(r,in);if(error)return error;
 memset(r->output,0,sizeof(r->output));r->job=(stm3_job){r->input,get32(in+4),r->output,r->header.output_limit,0,0};
 ++r->job_id;r->state=STM3_RUNNING;r->error=0;r->steps=0;r->max_slice_us=0;r->started=now(r);r->deadline_us=get32(in+8)*1000;
 const uint32_t result=invoke(r,STM3_INIT);
 if(r->state==STM3_FAULT)return r->error;
 if(result==STM3_DONE)r->state=STM3_FINISHED;
 else if(result!=STM3_MORE){fault(r,STM3_E_MODULE);return STM3_E_MODULE;}
 return STM3_OK;
}
static void finish_deferred(stm3_runtime*r);
void stm3_tick(stm3_runtime*r){
 if(r->state==STM3_RUNNING){
  if(now(r)-r->started>r->deadline_us||r->steps>=10000)fault(r,STM3_E_TIME);
  else{
   ++r->steps;const uint32_t result=invoke(r,STM3_STEP);
   if(r->state!=STM3_FAULT){
    if(result==STM3_DONE)r->state=STM3_FINISHED;
    else if(result!=STM3_MORE)fault(r,STM3_E_MODULE);
   }
  }
 }
 if(r->deferred&&r->state!=STM3_RUNNING)finish_deferred(r);
}
void stm3_command(stm3_runtime*r,uint8_t command,const uint8_t*in,uint16_t n,uint8_t*out,uint16_t*out_n){
 uint32_t error=STM3_OK;unsigned used=4;
 switch(command){
 case M3B_ENTER:
  if(n!=8 || get32(in)!=M3B_ENTER_MAGIC || get32(in+4)!=M3B_TARGET){error=STM3_E_ARGUMENT;break;}
  if(r->state!=STM3_EMPTY){error=STM3_E_STATE;break;}
  bios_update_requested=1;break;
 case STM3_HELLO:
  if(n){error=STM3_E_ARGUMENT;break;}
  put32(out+4,STM3_ABI);put32(out+8,STM3_TARGET);put32(out+12,STM3_IMAGE_CAPACITY);put32(out+16,STM3_IO_CAPACITY);
  put32(out+20,r->state);put32(out+24,r->bad_frames);put32(out+28,r->sequence_conflicts);
  put32(out+32,r->backend.baud);put32(out+36,(r->backend.transport_flags|STM3_TRANSPORT_START_RESULT|STM3_TRANSPORT_START_RESULT_INPUT|STM3_TRANSPORT_RESULT_V2)|16u);used=40;break;
 case STM3_LOAD_BEGIN:
  if(n!=4){error=STM3_E_ARGUMENT;break;}
  if(r->state==STM3_RUNNING||r->state==STM3_LOADING||r->state==STM3_READY||r->state==STM3_FINISHED||r->state==STM3_CANCELLED){error=STM3_E_STATE;break;}
  if(get32(in)<64||get32(in)>STM3_PACKAGE_CAPACITY){error=STM3_E_SIZE;break;}
  memset(r->arena.bytes,0,sizeof(r->arena.bytes));memset(&r->header,0,sizeof(r->header));memset(&r->job,0,sizeof(r->job));r->entry=0;
  r->package_bytes=get32(in);r->received=0;r->state=STM3_LOADING;r->error=0;break;
 case STM3_LOAD_CHUNK:
  if(n<5){error=STM3_E_ARGUMENT;break;}
  if(r->state!=STM3_LOADING){error=STM3_E_STATE;break;}
  if(get32(in)!=r->received||n-4u>r->package_bytes-r->received){error=STM3_E_SIZE;break;}
  memcpy(r->arena.bytes+r->received,in+4,n-4);r->received+=n-4;put32(out+4,r->received);used=8;break;
 case STM3_LOAD_COMMIT:
  if(n){error=STM3_E_ARGUMENT;break;}
  error=commit(r);if(error){if(r->state==STM3_LOADING)fault(r,error);break;}
  put32(out+4,r->module_id);used=8;break;
 case STM3_WRITE:
  if(n<4){error=STM3_E_ARGUMENT;break;}
  if(r->state!=STM3_READY&&r->state!=STM3_FINISHED&&r->state!=STM3_CANCELLED){error=STM3_E_STATE;break;}
  if(get32(in)>r->header.input_limit||n-4u>r->header.input_limit-get32(in)){error=STM3_E_SIZE;break;}
  memcpy(r->input+get32(in),in+4,n-4);break;
 case STM3_START:{
  if(n!=12){error=STM3_E_ARGUMENT;break;}
  error=start_job(r,in);if(error)break;
  put32(out+4,r->job_id);used=8;break;}
 case STM3_START_RESULT:
 case STM3_START_RESULT_INPUT:{
  if(n<16){error=STM3_E_ARGUMENT;break;}
  const uint32_t input_bytes=get32(in+4);uint32_t count=get32(in+12);
  if(count>STM3_RESULT_LIMIT||count>r->header.output_limit){error=STM3_E_SIZE;break;}
  if(command==STM3_START_RESULT_INPUT){
   if(input_bytes>STM3_START_RESULT_INPUT_LIMIT||n!=16u+input_bytes){error=STM3_E_SIZE;break;}
   error=check_job(r,in);if(error)break;
   memcpy(r->input,in+16,input_bytes);
  }else if(n!=16){error=STM3_E_ARGUMENT;break;}
  error=start_job(r,in);if(error)break;
  if(r->state==STM3_RUNNING){r->deferred=1;r->deferred_count=count;*out_n=0;return;}
  if(count>r->job.output_bytes)count=r->job.output_bytes;
  put32(out+4,r->job_id);put32(out+8,r->max_slice_us);
  memcpy(out+12,r->output,count);used=12+count;break;}
 case STM3_STATUS:
  if(n!=4){error=STM3_E_ARGUMENT;break;}
  if(get32(in)!=r->job_id||!r->job_id){error=STM3_E_JOB;break;}
  put32(out+4,r->job_id);put32(out+8,r->state);put32(out+12,r->error);put32(out+16,r->job.progress);
  put32(out+20,r->job.output_bytes);put32(out+24,r->steps);put32(out+28,r->max_slice_us);used=32;break;
 case STM3_READ:{
  if(n!=12){error=STM3_E_ARGUMENT;break;}
  if(get32(in)!=r->job_id||!r->job_id){error=STM3_E_JOB;break;}
  if(r->state!=STM3_FINISHED){error=STM3_E_STATE;break;}
  if(get32(in+8)>STM3_WIRE_PAYLOAD-4||get32(in+4)>r->job.output_bytes||get32(in+8)>r->job.output_bytes-get32(in+4)){error=STM3_E_SIZE;break;}
  // Request and response payloads may share memory after in-place decoding.
  const uint32_t offset=get32(in+4),count=get32(in+8);
  memcpy(out+4,r->output+offset,count);used+=count;break;}
 case STM3_CANCEL_JOB:
  if(n!=4){error=STM3_E_ARGUMENT;break;}
  if(get32(in)!=r->job_id||!r->job_id){error=STM3_E_JOB;break;}
  if(r->state!=STM3_RUNNING){error=STM3_E_STATE;break;}
  (void)invoke(r,STM3_CANCEL);if(r->state!=STM3_FAULT)r->state=STM3_CANCELLED;else error=r->error;break;
 case STM3_UNLOAD:
  if(n){error=STM3_E_ARGUMENT;break;}
  if(r->state==STM3_RUNNING){error=STM3_E_STATE;break;}
  if(r->state!=STM3_LOADING&&r->state!=STM3_EMPTY&&r->entry)(void)invoke(r,STM3_FINI);
  memset(r->arena.bytes,0,sizeof(r->arena.bytes));memset(r->input,0,sizeof(r->input));memset(r->output,0,sizeof(r->output));
  memset(&r->header,0,sizeof(r->header));memset(&r->job,0,sizeof(r->job));r->entry=r->received=r->package_bytes=0;r->error=0;r->state=STM3_EMPTY;break;
 default:error=STM3_E_ARGUMENT;break;
 }
 put32(out,error);*out_n=(uint16_t)(error?4:used);
}
unsigned stm3_cobs_encode(const uint8_t*in,unsigned n,uint8_t*out,unsigned cap){
 if(!cap)return 0;
 unsigned at=1,code_at=0;uint8_t code=1;
 for(unsigned i=0;i<n;++i){if(!in[i]){out[code_at]=code;code_at=at++;code=1;if(at>cap)return 0;}else{if(at>=cap)return 0;out[at++]=in[i];if(++code==255){out[code_at]=code;code_at=at++;code=1;if(at>cap)return 0;}}}
 out[code_at]=code;return at;
}
unsigned stm3_cobs_decode(const uint8_t*in,unsigned n,uint8_t*out,unsigned cap){
 unsigned at=0,i=0;
 while(i<n){const unsigned code=in[i++];if(!code||code-1>n-i)return 0;for(unsigned j=1;j<code;++j){if(at>=cap||!in[i])return 0;out[at++]=in[i++];}if(code!=255&&i<n){if(at>=cap)return 0;out[at++]=0;}}
 return at;
}
static void reply(stm3_runtime*r,unsigned response){
 r->frame[0]=2;r->frame[1]=(uint8_t)(r->last_cmd|128);r->frame[2]=(uint8_t)r->last_seq;r->frame[3]=(uint8_t)(r->last_seq>>8);
 r->frame[4]=(uint8_t)response;r->frame[5]=(uint8_t)(response>>8);r->frame[6]=r->frame[7]=0;
 put32(r->frame+8+response,stm3_crc32(r->frame,8+response));
 unsigned encoded=stm3_cobs_encode(r->frame,12+response,r->tx,sizeof(r->tx)-1);
 if(!encoded){++r->bad_frames;return;}r->tx[encoded++]=0;r->tx_bytes=encoded;r->tx_at=0;r->have_reply=1;
}
static void finish_deferred(stm3_runtime*r){
 // Rebuild the header: duplicate/noisy RX frames may have reused frame[].
 uint32_t error=r->state==STM3_FAULT?r->error:STM3_OK;unsigned used=4;
 if(!error&&r->state!=STM3_FINISHED)error=STM3_E_STATE;
 const uint32_t count=r->deferred_count<r->job.output_bytes?r->deferred_count:r->job.output_bytes;
 put32(r->frame+8,error);
 if(!error){
  put32(r->frame+12,r->job_id);put32(r->frame+16,r->max_slice_us);
  memcpy(r->frame+20,r->output,count);used=12+count;
 }
 r->deferred=0;reply(r,used);
}
void stm3_feed(stm3_runtime*r,uint8_t value){
 if(value){if(!r->frame_overflow){if(r->frame_bytes<sizeof(r->frame))r->frame[r->frame_bytes++]=value;else r->frame_overflow=1;}return;}
 if(!r->frame_bytes&&!r->frame_overflow)return;
 unsigned bytes=r->frame_overflow?0:stm3_cobs_decode(r->frame,r->frame_bytes,r->frame,sizeof(r->frame));r->frame_bytes=r->frame_overflow=0;
 if(bytes<12||r->frame[0]!=2||r->frame[1]&128||r->frame[6]||r->frame[7]){++r->bad_frames;return;}
 unsigned count=(unsigned)r->frame[4]|(unsigned)r->frame[5]<<8;
 if(count>STM3_WIRE_PAYLOAD||bytes!=12+count||stm3_crc32(r->frame,8+count)!=get32(r->frame+8+count)){++r->bad_frames;return;}
 const unsigned seq=(unsigned)r->frame[2]|(unsigned)r->frame[3]<<8;
 const unsigned crc=get32(r->frame+8+count),cmd=r->frame[1];
 // A duplicate pending START_RESULT never starts a second job. A different
 // request cannot steal the sole reply buffer while completion is pending.
 if(r->deferred){if(seq!=r->last_seq||cmd!=r->last_cmd||crc!=r->last_request_crc)++r->sequence_conflicts;return;}
 if(r->have_reply&&seq==r->last_seq){if(cmd==r->last_cmd&&crc==r->last_request_crc)r->tx_at=0;else ++r->sequence_conflicts;return;}
 if(r->tx_at<r->tx_bytes){++r->sequence_conflicts;return;}
 uint16_t response=0;
 // Commands consume their inputs before writing the overlapping response.
 stm3_command(r,(uint8_t)cmd,r->frame+8,(uint16_t)count,r->frame+8,&response);
 r->last_seq=seq;r->last_cmd=cmd;r->last_request_crc=crc;r->have_reply=0;
 if(response)reply(r,response);
}
unsigned stm3_transmit(stm3_runtime*r,uint8_t*out,unsigned cap){unsigned n=r->tx_bytes-r->tx_at;if(n>cap)n=cap;memcpy(out,r->tx+r->tx_at,n);r->tx_at+=n;return n;}
