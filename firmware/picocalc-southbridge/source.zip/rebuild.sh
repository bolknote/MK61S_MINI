#!/usr/bin/env bash
set -euo pipefail
: "${STM32_DRIVERS:?Absolute path to pinned Southbridge Drivers directory}"
: "${ARM_GCC_BIN:?Directory containing arm-none-eabi-gcc 14.2.1}"
replay_root="$(cd "$(dirname "$0")" && pwd)"
if [[ ! -e "$replay_root/source/Drivers" ]]; then
    ln -s "$STM32_DRIVERS" "$replay_root/source/Drivers"
fi
make -C "$replay_root/source" -j4 "GCC_PATH=$ARM_GCC_BIN" 'OPT=-Os -flto' BUILD_DIR=build
python3 - "$replay_root/source/build/picocalc_BIOS_jcs.bin" <<'CHECK'
import hashlib,sys
from pathlib import Path
actual=hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest()
assert actual=='3b313836c5fa260851c4a8cc6dc4bca8b3c98b7270cc9e484932cd7f268e7282',actual
print('Exact firmware SHA256 reproduced:',actual)
CHECK
