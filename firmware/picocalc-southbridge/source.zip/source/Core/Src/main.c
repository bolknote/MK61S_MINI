/**
  ******************************************************************************
  *
  * Copyright (c) 2025 C.ARE (JackCarterSmith).
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  *
  ******************************************************************************
  *
  * SYS_LED and COL_x are open-drain, output logic is inverted.
  *
  * Unless requested by the user through REG_ID_PWR_CTRL register or by removing
  * the batteries, pressing the power button when running now put the STM32 in
  * low-power stop mode and shutdown the PICO board.
  * It's the only mean to keep the RTC functional.
  * A full shutdown using AXP2101 power-off or by removing the batteries will
  * reset the RTC and disable auto wake-up feature.
  *
  */

#include "hal_interface.h"
#include "power_status.h"
#include "axp2101.h"
#include "backlight.h"
#include "batt.h"
#include "eeprom.h"
#include "fifo.h"
#include "keyboard.h"
#include "i2cs.h"
#include "i2cs_recovery.h"
#include "regs.h"
#include "rtc.h"


// Private define ------------------------------------------------------------
//#define DEFAULT_LCD_BL	(205)	// ~40% PWM@7.81kHz (9 bits resolution)
//#define DEFAULT_KBD_BL	(20)	// ~4% PWM@7.81kHz (9 bits resolution)
#define DEFAULT_LCD_BL		(32)		// stock raw brightness
#define DEFAULT_KBD_BL		(0)		//step-1 (0%)
#define DEFAULT_KBD_FREQ	(KEY_POLL_TIME)
#define DEFAULT_KBD_DEB		(KEY_HOLD_TIME)
#define DEFAULT_RCT_CFG		(0x00)

#ifdef DEBUG
#define DEBUG_UART_MSG(msg)			HAL_UART_Transmit(&huart1, (uint8_t*)msg, sizeof(msg)-1, 1000)
//#define DEBUG_UART_MSG2(d,s)		HAL_UART_Transmit(&huart1, (uint8_t*)d, s, 200)
#define DEBUG_UART_MSG2(d,sz, swp)	uart_rawdata_write(d,sz,swp)
#endif


// Private typedef -----------------------------------------------------------


// Private variables ---------------------------------------------------------

// Peripherals interface
extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c2;

extern RTC_HandleTypeDef hrtc;

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

#ifdef DEBUG
// Debug UART interface, unused in release to limit consumption mainly
extern UART_HandleTypeDef huart1;
static const uint8_t hexmap[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
#endif
#ifdef UART_PICO_INTERFACE
extern UART_HandleTypeDef huart3;
#endif

// Some globals/internals counters
static uint32_t pmu_check_counter = 0;
static uint8_t uninhibit_pwr_button = 0;
static volatile uint32_t off_delay_counter = 0;

// Global status
static uint8_t keycb_start = 0;
static uint32_t head_phone_status = 0;
volatile uint8_t pmu_irq = 0;
static uint8_t pmu_online = 0;
static volatile uint8_t stop_mode_active = 0;
static volatile uint8_t pwr_off_active = 0;


// Private variables ---------------------------------------------------------
static void lock_cb(const uint8_t caps_changed, const uint8_t num_changed);
static void key_cb(char key, enum key_state state);
static void hw_check_HP_presence(void);
static void sync_bat(void);
static void check_pmu_int(void);
static void rtc_ctrl_reg_check(void);
static void rst_ctrl_reg_check(void);
static void off_ctrl_reg_check(void);
static void sys_prepare_sleep(void);
static void sys_wake_sleep(void);

extern void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	if (htim == &htim2) {
		systicks_counter += 1;
	}
}

#ifdef DEBUG
void uart_rawdata_write(uint32_t c, size_t s, uint8_t swap) {
	uint8_t r[4];
	uint32_t v = swap ? __REV(c) : c;

	HAL_UART_Transmit(&huart1, (uint8_t*)"0x", 2, 40);
	for (size_t i = 0; i < s; i++) {
		uint8_t index = swap ? (uint8_t)(4-s+i) : (uint8_t)i;
		r[0] = hexmap[(((uint8_t*)&v)[index] & 0xF0) >> 4];
		r[1] = hexmap[((uint8_t*)&v)[index] & 0x0F];
		HAL_UART_Transmit(&huart1, r, 2, 40);
	}
}
#endif


/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {
	uint32_t result = 0;

	// Initialize the STM32 HAL system
	result = HAL_Interface_init();
	if (result != HAL_OK)
		Error_Handler();

	// Start the systick timer
	if (HAL_TIM_Base_Start_IT(&htim2) != HAL_OK)
		Error_Handler();

	LL_GPIO_ResetOutputPin(SYS_LED_GPIO_Port, SYS_LED_Pin);	// I'm alive!

	// EEPROM emulation init
	if (EEPROM_Init() != EEPROM_SUCCESS)
		Error_Handler();
#ifdef DEBUG
	DEBUG_UART_MSG("EEPROM init\n\r");
#endif

	// Check EEPROM first run
	EEPROM_ReadVariable(EEPROM_VAR_ID, (EEPROM_Value*)&result);
	if ((uint16_t)result != 0xCA3C) {
		EEPROM_WriteVariable(EEPROM_VAR_BCKL, (EEPROM_Value)(uint16_t)((DEFAULT_LCD_BL << 8) | DEFAULT_KBD_BL), EEPROM_SIZE16);
		EEPROM_WriteVariable(EEPROM_VAR_KBD, (EEPROM_Value)(uint32_t)((DEFAULT_KBD_DEB << 16) | DEFAULT_KBD_FREQ), EEPROM_SIZE32);
		EEPROM_WriteVariable(EEPROM_VAR_CFG, (EEPROM_Value)(uint16_t)(((CFG_EEPROM_SAVE_CFG | CFG_USE_MODS | CFG_REPORT_MODS | CFG_RST_DELAY_1S) << 8) | (INT_OVERFLOW | INT_KEY | INT_RTC | INT_PWR_BTN)), EEPROM_SIZE16);
		EEPROM_WriteVariable(EEPROM_VAR_ID, (EEPROM_Value)(uint16_t)0xCA3C, EEPROM_SIZE16);
#ifdef DEBUG
		DEBUG_UART_MSG("EEPROM first start!\n\r");
#endif
	}

	// Check RTC SRAM first run
	if (HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR1) == 0) {
		HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR1, 0xCA1C);
		HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR2, rtc_alarm_date.raw & 0xFFFF);
		HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR3, rtc_alarm_date.raw >> 16);
		HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR4, ((rtc_alarm_time.raw & 0xFF) << 8) | DEFAULT_RCT_CFG);
		HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR5, rtc_alarm_time.raw >> 16);
		// RTC_BKP_DR6/7 - rtc_date will be sync in force_date_bck_sync()
	}
	force_rtc_bck_load();
	force_rtc_bck_sync();

	// I2C-Pico interface registers
	reg_init();
	HAL_Delay(10);
	if (HAL_I2C_EnableListen_IT(&hi2c1) != HAL_OK)
		Error_Handler();

	// Check for AXP2101 is accessible on secondary I2C bus
	result = 0;
	HAL_I2C_Mem_Read(&hi2c2, 0x68, XPOWERS_AXP2101_IC_TYPE, 1, (uint8_t*)&result, 1, 60);
	if (result == XPOWERS_AXP2101_CHIP_ID) {
#ifdef DEBUG
		DEBUG_UART_MSG("PMU ID: ");
		DEBUG_UART_MSG2((uint32_t)result, 1, 0);
		DEBUG_UART_MSG("\n\r");
#endif
		pmu_online = 1;
	}
#ifdef DEBUG
	else {
		DEBUG_UART_MSG("PMU not online!\n\r");
	}
#endif

	// Start LCD and KBD backlight PWM
	lcd_backlight_off();
	if (HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1) != HAL_OK)
		Error_Handler();
	kbd_backlight_on();
	if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3) != HAL_OK)
		Error_Handler();
#ifdef DEBUG
	DEBUG_UART_MSG("Bckl params: ");
	DEBUG_UART_MSG2(((uint32_t)result >> 8), 1, 1);
	DEBUG_UART_MSG(", ");
	DEBUG_UART_MSG2(((uint32_t)result & 0xFF), 1, 1);
	DEBUG_UART_MSG("\n\r");
#endif
	keyboard_set_key_callback(key_cb);
	keyboard_set_lock_callback(lock_cb);

	// It is necessary to disable the detection function of the TS pin on the
	// board without the battery temperature detection function, otherwise it will
	// cause abnormal charging
	AXP2101_setSysPowerDownVoltage(2800);
	AXP2101_disableTSPinMeasure();
	AXP2101_setPowerOnPressDelay(XPOWERS_AXP2101_ON_LVL_512MS);
	AXP2101_setPowerOffPressDelay(XPOWERS_AXP2101_OFF_LVL_10S);
	AXP2101_enablePwrOffAfterOffDelay();
	// AXP2101_enableTemperatureMeasure();
	AXP2101_enableBattDetection();
	AXP2101_enableVbusVoltageMeasure();
	AXP2101_enableBattVoltageMeasure();
	AXP2101_enableSystemVoltageMeasure();

	AXP2101_setChargingLedMode(XPOWERS_CHG_LED_CTRL_CHG);

	AXP2101_disableIRQ(XPOWERS_AXP2101_ALL_IRQ);
	AXP2101_clearIrqStatus();
	AXP2101_enableIRQ(XPOWERS_AXP2101_BAT_INSERT_IRQ |
					XPOWERS_AXP2101_BAT_REMOVE_IRQ |  // BATTERY
					XPOWERS_AXP2101_WARNING_LEVEL1_IRQ |
					XPOWERS_AXP2101_VBUS_INSERT_IRQ |
					XPOWERS_AXP2101_VBUS_REMOVE_IRQ |  // VBUS
					//XPOWERS_AXP2101_PKEY_SHORT_IRQ |
					//XPOWERS_AXP2101_PKEY_LONG_IRQ |  // POWER KEY - inhibit for startup
					XPOWERS_AXP2101_BAT_CHG_DONE_IRQ |
					XPOWERS_AXP2101_BAT_CHG_START_IRQ  // CHARGE
	);
	// setLowBatWarnThreshold Range:  5% ~ 20%
	// The following data is obtained from actual testing , Please see the description below for the test method.
	// 20% ~= 3.7v
	// 15% ~= 3.6v
	// 10% ~= 3.55V
	// 5%  ~= 3.5V
	// 1%  ~= 3.4V
	AXP2101_setLowBatWarnThreshold(20); // Set to trigger interrupt when reaching 20%

	// setLowBatShutdownThreshold Range:  0% ~ 15%
	// The following data is obtained from actual testing , Please see the description below for the test method.
	// 15% ~= 3.6v
	// 10% ~= 3.55V
	// 5%  ~= 3.5V
	// 1%  ~= 3.4V
	AXP2101_setLowBatShutdownThreshold(5);  //This is related to the battery charging and discharging logic. If you're not sure what you're doing, please don't modify it, as it could damage the battery.

	keycb_start = 1;
	keyboard_process();
	sync_bat();
	low_bat();

	coproc_setup();
	bios_power_refresh(pmu_online);

	// PICO MCU start
	sys_start_pico();
#ifdef DEBUG
	DEBUG_UART_MSG("Pico started\n\r");
#endif
	lcd_backlight_on();

	while (1) {
		// Re-arm I2CS in wrong case scenarios
		if (i2cs_recover_required || (i2cs_state != I2CS_STATE_IDLE && ((uptime_ms() - i2cs_rearm_counter) > I2CS_REARM_TIMEOUT)) ||
			HAL_I2C_GetState(&hi2c1) == HAL_I2C_STATE_ERROR
		) {
			if (i2cs_state == I2CS_STATE_REG_REQUEST)
				led_blink_configure(3, 1);
			else if (i2cs_state == I2CS_STATE_REG_RECEIVE)
				led_blink_configure(2, 1);
			else
				led_blink_configure(1, 1);
			i2cs_recover_required = 0;
			i2cs_state = I2CS_STATE_IDLE;
			HAL_Interface_I2C1_reset();
		}

		if (coproc_storage_idle()) reg_sync();
		check_rtc_bck_sync();
		check_pmu_int();
		bios_power_poll(pmu_online);
		keyboard_process();
		coproc_poll();
		hw_check_HP_presence();
		rtc_ctrl_reg_check();
		rst_ctrl_reg_check();
		off_ctrl_reg_check();
		led_blink_refresh();

		HAL_RTC_GetDate(&hrtc, &rtc_date._s, RTC_FORMAT_BIN);
		HAL_RTC_GetTime(&hrtc, &rtc_time._s, RTC_FORMAT_BIN);

		// If power off is requested, override sleep mode. TODO: transform to FSM instead
		if (pwr_off_active == 1) {
			// Execute shutdown if requested
			if (uptime_ms() >= off_delay_counter) {
				sys_stop_pico();
				AXP2101_setChargingLedMode(XPOWERS_CHG_LED_CTRL_CHG);
				AXP2101_shutdown();		// Full shudown will rip the RTC configuration! Need to be reset at next reboot.
			}
		}
		// Execute stop/sleep mode if requested
		else if (stop_mode_active == 1) {
			if (uptime_ms() >= off_delay_counter) {
				reg_unset_bit(REG_ID_OFF, OFF_CTRL_SLEEP);
				// Prepare peripherals to the low-power mode
				force_rtc_bck_sync();
				sys_stop_pico();
				keycb_start = 0;
				AXP2101_setChargingLedMode(XPOWERS_CHG_LED_CTRL_CHG);
				uninhibit_pwr_button = 0;
				sys_prepare_sleep();

				// Low-power mode entry
				coproc_enter_sleep();
				HAL_Delay(300);

				// Wake-up peripherals from low-power mode
				sys_wake_sleep();
				force_rtc_bck_load();
				force_rtc_bck_sync();
				// Keyboard reset for detecting boot key press
				fifo_flush();
				keyboard_reset();
				keycb_start = 1;
				keyboard_process();
				sys_start_pico();
				stop_mode_active = 0;
			}
		}
	}
}



// Private functions ---------------------------------------------------------

static void lock_cb(const uint8_t caps_changed, const uint8_t num_changed) {
	uint8_t int_trig = 0;

	if (caps_changed && reg_is_bit_set(REG_ID_INT_CFG, INT_CAPSLOCK)) {
		reg_set_bit(REG_ID_INT, INT_CAPSLOCK);
		int_trig = 1;
	}

	if (num_changed && reg_is_bit_set(REG_ID_INT_CFG, INT_NUMLOCK)) {
		reg_set_bit(REG_ID_INT, INT_NUMLOCK);
		int_trig = 1;
	}

#ifndef UART_PICO_INTERFACE
	if (int_trig == 1)
		LL_GPIO_ResetOutputPin(PICO_IRQ_GPIO_Port, PICO_IRQ_Pin);		// Assert the IRQ signal to the pico
#endif
}

static void key_cb(char key, enum key_state state) {
	uint8_t int_trig = 0;

	if (keycb_start == 0) {
		fifo_flush();
		return;
	}

	if (reg_is_bit_set(REG_ID_INT_CFG, INT_KEY)) {
		reg_set_bit(REG_ID_INT, INT_KEY);
		int_trig = 1;
	}

#ifdef DEBUG
	DEBUG_UART_MSG("key: ");
	DEBUG_UART_MSG2(key, 1, 0);
	DEBUG_UART_MSG("\n\r");
	DEBUG_UART_MSG("state: ");
	DEBUG_UART_MSG2(state, 1, 0);
	//DEBUG_UART_MSG(" blk: ");
	//DEBUG_UART_MSG2(reg_get_value(REG_ID_BKL), 1, 0);
	DEBUG_UART_MSG("\n\r");
#endif

	const struct fifo_item item = {key, state};
	if (!fifo_enqueue(item)) {
		if (reg_is_bit_set(REG_ID_INT_CFG, INT_OVERFLOW)) {
			reg_set_bit(REG_ID_INT, INT_OVERFLOW);  // INT_OVERFLOW  The interrupt was generated by FIFO overflow.
			int_trig = 1;
		}

		if (reg_is_bit_set(REG_ID_SYS_CFG, CFG_OVERFLOW_ON))
			fifo_enqueue_force(item);
	}

#ifndef UART_PICO_INTERFACE
	if (int_trig == 1)
		LL_GPIO_ResetOutputPin(PICO_IRQ_GPIO_Port, PICO_IRQ_Pin);		// Assert the IRQ signal to the pico
#endif
}

__STATIC_INLINE void hw_check_HP_presence(void) {
	uint32_t v = LL_GPIO_IsInputPinSet(HP_DET_GPIO_Port, HP_DET_Pin);

	if (v != head_phone_status) {
		if (v != 0) {
#ifdef DEBUG
			DEBUG_UART_MSG("HeadPhone inserted\n\r");
#endif
			LL_GPIO_ResetOutputPin(SP_AMP_EN_GPIO_Port, SP_AMP_EN_Pin);
		} else {
#ifdef DEBUG
			DEBUG_UART_MSG("HeadPhone removed\n\r");
#endif
			LL_GPIO_SetOutputPin(SP_AMP_EN_GPIO_Port, SP_AMP_EN_Pin);
		}

		head_phone_status = v;
	}
}

__STATIC_INLINE void sync_bat(void) {
	uint8_t pcnt;
	if (AXP2101_getBatteryPercent(&pcnt) != HAL_OK)
		return;
#ifdef DEBUG
	DEBUG_UART_MSG("check_pmu_int: ");
	DEBUG_UART_MSG2((uint32_t)pcnt, 1, 0);
	DEBUG_UART_MSG("\n\r");
#endif

	if (pcnt > 100) {  // disconnect
		pcnt = 0;
	} else {  // battery connected
		if (AXP2101_isCharging())
			pcnt |= (1 << 7);
		low_bat();
	}

	reg_set_value(REG_ID_BAT, pcnt);
}

__STATIC_INLINE void check_pmu_int(void) {
	if (!pmu_online)
		return;

	uint8_t pcnt;

	if (uptime_ms() - pmu_check_counter > 10000) {
		pmu_check_counter = uptime_ms();  // reset time

		// Remove start-up inhibit on
		if (uninhibit_pwr_button == 0) {
			AXP2101_enableIRQ(XPOWERS_AXP2101_PKEY_SHORT_IRQ | XPOWERS_AXP2101_PKEY_LONG_IRQ);
			uninhibit_pwr_button = 1;
		}

		AXP2101_getBatteryPercent(&pcnt);
#ifdef DEBUG
		DEBUG_UART_MSG("check_pmu_int: ");
		DEBUG_UART_MSG2((uint32_t)pcnt, 1, 0);
		DEBUG_UART_MSG("\n\r");
#endif

		if (pcnt > 100) {  // disconnect
			pcnt = 0;
		} else {  // battery connected
			if (AXP2101_isCharging())
				pcnt |= (1 << 7);
			low_bat();
		}

		reg_set_value(REG_ID_BAT,pcnt);
	}

	if (pmu_irq) {
		pmu_irq = 0;	// Reset interrupt flag

		// Get PMU Interrupt Status Register
		uint32_t status;
		AXP2101_getIrqStatus(&status);
#ifdef DEBUG
		DEBUG_UART_MSG("PMU IRQ status: ");
		DEBUG_UART_MSG2(status, 4, 1);
		DEBUG_UART_MSG("\n\r");
#endif

		/*
		// When the set low-voltage battery percentage warning threshold is reached,
		// set the threshold through getLowBatWarnThreshold( 5% ~ 20% )
		if (PMU.isDropWarningLevel2Irq()) {
		  Serial1.println("isDropWarningLevel2");
		  //report_bat();
		}
		*/

		// When the set low-voltage battery percentage shutdown threshold is reached
		// set the threshold through setLowBatShutdownThreshold()
		if (AXP2101_isDropWarningLevel1Irq()) {
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isDropWarningLevel1\n\r");
#endif
			//report_bat();
			//
			AXP2101_shutdown();
		}
		/*if (PMU.isVbusInsertIrq()) {
		  Serial1.println("isVbusInsert");
		}*/
		if (AXP2101_isVbusRemoveIrq()) {
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isVbusRemove\n\r");
#endif
			stop_chg();
		}

		if (AXP2101_isBatInsertIrq()) {
			AXP2101_getBatteryPercent(&pcnt);
			if (pcnt > 100) {  // disconnect
				pcnt = 0;
			} else {  // battery connected
				pcnt |= (1 << 7);
			}
			reg_set_value(REG_ID_BAT, pcnt);
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isBatInsert\n\r");
#endif
		}

		if (AXP2101_isBatRemoveIrq()) {
			reg_set_value(REG_ID_BAT,0);
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isBatRemove\n\r");
#endif
			stop_chg();
		}

		if (AXP2101_isPkeyShortPressIrq()) {
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isPekeyShortPress\n\r");

			uint8_t data[4] = {0};
			AXP2101_readDataBuffer(data, XPOWERS_AXP2101_DATA_BUFFER_SIZE);
			DEBUG_UART_MSG("PMU data buffer:\n\r");
			DEBUG_UART_MSG2(data[0], 1, 0);
			DEBUG_UART_MSG("\n\r");
			DEBUG_UART_MSG2(data[1], 1, 0);
			DEBUG_UART_MSG("\n\r");
			DEBUG_UART_MSG2(data[2], 1, 0);
			DEBUG_UART_MSG("\n\r");
			DEBUG_UART_MSG2(data[3], 1, 0);
			DEBUG_UART_MSG("\n\r");

			printPMU();
#endif
			if (stop_mode_active == 0 && uninhibit_pwr_button == 1) {
				// Send the special key to keyboard FIFO, as legacy firmware do
				key_cb(KEY_POWER, KEY_STATE_PRESSED);

				// Check if this IRQ is configured and do the stuff
				if (reg_is_bit_set(REG_ID_INT_CFG, INT_PWR_BTN))
					reg_set_bit(REG_ID_INT, INT_PWR_BTN);

				// In the case of shift is pressed in the same time, do a pico reset
				if (keyboard_get_shift() && (reg_get_value(REG_ID_RST) == 0))
					reg_set_value(REG_ID_RST, RST_CTRL_PICO_RST);
			}
		}

		if (AXP2101_isPkeyLongPressIrq()) {
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isPekeyLongPress\n\r");
#endif
			//Serial1.println("write pmu data buffer .");
			//uint8_t data[4] = {1, 2, 3, 4};
			//PMU.writeDataBuffer(data, XPOWERS_AXP2101_DATA_BUFFER_SIZE);

			if (stop_mode_active == 0 && uninhibit_pwr_button == 1) {
				AXP2101_setChargingLedMode(XPOWERS_CHG_LED_CTRL_CHG);
				stop_mode_active = 1;
			}
		}

		if (AXP2101_isBatChargeDoneIrq()) {
			AXP2101_getBatteryPercent(&pcnt);
			if (pcnt > 100) {  // disconnect
				pcnt = 0;
			} else {  // battery connected
				pcnt |= (1 << 7);
			}
			reg_set_value(REG_ID_BAT,pcnt);
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isBatChagerDone\n\r");
#endif
			stop_chg();
		}

		if (AXP2101_isBatChargeStartIrq()) {
			AXP2101_getBatteryPercent(&pcnt);
			if (pcnt > 100) {  // disconnect
				pcnt = 0;
			} else {  // battery connected
				pcnt |= (1 << 7);
			}
			reg_set_value(REG_ID_BAT,pcnt);
#ifdef DEBUG
			DEBUG_UART_MSG("PMU: isBatChagerStart\n\r");
#endif
			if(AXP2101_isBatteryConnect())
				start_chg();
		}

		// Clear PMU Interrupt Status Register
		AXP2101_clearIrqStatus();
		bios_power_refresh(pmu_online);
	}
}

__STATIC_INLINE void rtc_ctrl_reg_check(void) {
	if (rtc_reg_xor_events != 0) {
		if ((rtc_reg_xor_events & RTC_CFG_ALARM_ENA) == RTC_CFG_ALARM_ENA) {
			if (reg_get_value(REG_ID_RTC_CFG) & RTC_CFG_ALARM_ENA) {
				if (rtc_run_alarm() != HAL_OK)
					reg_set_value(REG_ID_RTC_CFG, reg_get_value(REG_ID_RTC_CFG) & (uint8_t)~RTC_CFG_ALARM_ENA);
			} else {
				if (rtc_stop_alarm() != HAL_OK)
					reg_set_value(REG_ID_RTC_CFG, reg_get_value(REG_ID_RTC_CFG) | RTC_CFG_ALARM_ENA);
			}

			rtc_reg_xor_events &= (uint8_t)~RTC_CFG_ALARM_ENA;
		}
	}
}

__STATIC_INLINE void rst_ctrl_reg_check(void) {
	const uint8_t rst_reg = (reg_get_value(REG_ID_RST) & 0xC0);
    const uint8_t delay_mode = (uint8_t)(reg_get_value(REG_ID_SYS_CFG) & CFG_RST_DELAY);

    if (rst_reg == 0)
    	return;

    HAL_Delay(300);		// Wait for final I2C answer
    HAL_I2C_DisableListen_IT(&hi2c1);

	reg_set_value(REG_ID_RST, 0);
	sys_stop_pico();
	keycb_start = 0;

	if (delay_mode == CFG_RST_DELAY_1S)
		HAL_Delay(1000);
	else if (delay_mode == CFG_RST_DELAY_3S)
		HAL_Delay(3000);
	else if (delay_mode == CFG_RST_DELAY_5S)
		HAL_Delay(5000);
	else
		HAL_Delay(200);

	if (rst_reg == RST_CTRL_PICO_RST) {
        // Keyboard reset for detecting boot key press
        fifo_flush();
        keyboard_reset();
        keycb_start = 1;
        keyboard_process();

		if (HAL_I2C_EnableListen_IT(&hi2c1) != HAL_OK)
			HAL_Interface_I2C1_reset();

		sys_start_pico();
	} else if (rst_reg == RST_CTRL_FULL_RST) {
		NVIC_SystemReset();
	}
}

__STATIC_INLINE void off_ctrl_reg_check(void) {
	if (!(pwr_off_active || stop_mode_active)) {
		if (reg_get_value(REG_ID_OFF) & 0xC0) {
			uninhibit_pwr_button = 0;

			if (reg_is_bit_set(REG_ID_OFF, OFF_CTRL_SHUTDOWN))
				pwr_off_active = 1;
			else if (reg_is_bit_set(REG_ID_OFF, OFF_CTRL_SLEEP))
				stop_mode_active = 1;

			if (pwr_off_active || stop_mode_active)
				off_delay_counter = uptime_ms() + ((uint32_t)(reg_get_value(REG_ID_OFF) & 0x3F) * 1000);	// bits 5-0: delay in second
		}
	}
}

__STATIC_INLINE void sys_prepare_sleep(void) {
	LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

	keycb_start = 0;

	// Put PMIC in low-trigger mode
	AXP2101_disableIRQ(XPOWERS_AXP2101_ALL_IRQ);
	AXP2101_clearIrqStatus();
	AXP2101_enableIRQ(XPOWERS_AXP2101_PKEY_SHORT_IRQ |
					XPOWERS_AXP2101_PKEY_LONG_IRQ |
					XPOWERS_AXP2101_WARNING_LEVEL1_IRQ
	);

	// Backlights shut-off
	lcd_backlight_off();
	kbd_backlight_off();
	HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_3);

	// Disable I2C slave
	HAL_I2C_DisableListen_IT(&hi2c1);

	// Front LED switched in low-power mode
	GPIO_InitStruct.Pin = SYS_LED_Pin;
	GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
	GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
	GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
	LL_GPIO_Init(SYS_LED_GPIO_Port, &GPIO_InitStruct);
	LL_GPIO_SetOutputPin(SYS_LED_GPIO_Port, SYS_LED_Pin);
}

__STATIC_INLINE void sys_wake_sleep(void) {
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	// Restore front LED state
	GPIO_InitStruct.Pin = SYS_LED_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_MEDIUM;
	HAL_GPIO_Init(SYS_LED_GPIO_Port, &GPIO_InitStruct);
	LL_GPIO_ResetOutputPin(SYS_LED_GPIO_Port, SYS_LED_Pin);

	// Enable I2C slave
	if (HAL_I2C_EnableListen_IT(&hi2c1) != HAL_OK)
		HAL_Interface_I2C1_reset();

	// Restart backlights PWM
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
	HAL_Delay(300);
	kbd_backlight_on();
	lcd_backlight_on();

	// Re-enable complete IRQ from PMIC
	AXP2101_enableIRQ(XPOWERS_AXP2101_BAT_INSERT_IRQ |
					XPOWERS_AXP2101_BAT_REMOVE_IRQ |  // BATTERY
					XPOWERS_AXP2101_VBUS_INSERT_IRQ |
					XPOWERS_AXP2101_VBUS_REMOVE_IRQ |  // VBUS
					XPOWERS_AXP2101_BAT_CHG_DONE_IRQ |
					XPOWERS_AXP2101_BAT_CHG_START_IRQ  // CHARGE
	);

	// Keyboard reset for detecting boot key press
	fifo_flush();
	keyboard_reset();
	keycb_start = 1;
	keyboard_process();
}
